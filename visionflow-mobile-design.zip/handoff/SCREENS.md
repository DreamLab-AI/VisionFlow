# Screens

Twelve sections plus two overlays. All layouts at 390px. Every string is either verbatim from
`website/static/index.html` (technical voice) or from `PLAIN` / `PANES` in
`website/static/js/main.js` (plain voice). Trims are noted per section.

Global chrome on every screen: nav (54px) · progress bar (3px) · progress rail (right edge) ·
sticky action bar (94px). Content starts at 57px and ends with 130px of clearance.

---

## 01 — The offer

**Desktop source:** `#hero`
**Section wash:** none. The mesh is fully visible; the hero → 02 handover is a gradient.

```
  01  COORDINATION
      ENGINEERING

  Federated
  Human–AI          ← gold gradient on line 2 only
  Intelligence
  ━━━━━━━━━━━━━━━━  ← 2px foil rule, fades right

  As AI collapses the cost of routing
  work, the human is promoted from
  router to judgment broker.

  ────────────  ────────────
  6             82
  SUBSTRATES    CUDA KERNELS
  ────────────  ────────────
  180+          55×
  MCP TOOLS     GPU SPEEDUP

  ENTER THE MESH ↓
```

| Element | Spec |
|---|---|
| H1 | 36/1.08/700/-.025em. Three lines; line 2 (`Human–AI`) takes the gold gradient, lines 1 and 3 are `#f0eded` |
| Foil rule | 2px, `linear-gradient(90deg, #ffd700, #cd7f32, transparent)`, 22px above and below |
| Lead | 17/1.6, Body |
| Stats | 2×2 grid, `gap: 10px`, each `flex: 1 1 40%` with a `2px solid rgba(255,215,0,.35)` top rule. Figure 30/700 gold gradient; label 10px mono `.14em` |
| Scroll cue | 10px mono `.22em` + `↓` on the existing `cueBob` animation |

**Copy change — the only one in the pack.** The shipped `.hero-sub` is 132 words. It is cut to
its last clause for the technical voice:

> As AI collapses the cost of routing work, the human is promoted from router to judgment broker.
> Thin agents on a shared formal semantic layer, with self-sovereign data and cryptographic
> provenance.

The dropped sentences ("Coordination engineering is the discipline of…", the neurosymbolic
aside) are not lost — they are the definition of the term, and the term is now the eyebrow. If
the full paragraph must ship, it belongs under a "What is coordination engineering?" disclosure.

The plain voice is `PLAIN.hero.lead` verbatim, cut to its first two clauses.

**Dropped:** the two `.btn` calls to action. "Explore the Architecture" scrolls to a section
that is now three taps away in the index; "View on GitHub" is in the index and the footer. The
sticky bar carries the one action.

**H1 gradient and accessibility.** The shipped H1 uses `-webkit-text-fill-color: transparent`
with `background-clip: text`. Keep the `color: var(--bright-gold)` fallback declaration that is
already in `.hero h1` — it is what renders if `background-clip` fails.

---

## 02 — Problem

**Desktop source:** `#problem` · **Treatment:** full

| Voice | H2 | Lead |
|---|---|---|
| Technical | Hard problems share a common shape | "Climate modelling, drug discovery, organisational transformation, creative production at scale — diverse intelligence collaborating across trust boundaries, at scales where centralised coordination breaks down." |
| Plain | More AI means more coordination, not less | `PLAIN.problem.lead`, first clause |

Four foil-ruled rows replacing four `.glass-card`s. The `✖` icons are dropped — four crimson
marks in a column read as an error state, and the rows are already a list of failures.

| Row | Second line |
|---|---|
| Centralised AI | Scales tokens but not trust |
| Agent frameworks | Scale tasks but not governance |
| Knowledge tools | Scale information but not reasoning |
| Collaboration platforms | Scale communication but not coordination |

Each second line is the shipped card copy cut to its first sentence; the second sentences ("One
vendor, one failure mode…", "Fast and broken is still broken.") are good lines but four of them
in a column is 8 lines of body copy for a point made in 4.

Closes with the **emphasis block** (`COMPONENTS.md` §15): `73%` at 40px, then
`PLAIN.problem.callout` trimmed — "of frontline AI adoption happens without management sign-off.
Your organisation is becoming an agentic mesh whether you plan for it or not."

---

## 03 — Six substrates

**Desktop source:** `#substrates` · **Treatment:** condensed
**Mesh:** the ontology ring figure binds here (see `COMPONENTS.md` §12).

H2: "Six independent systems, one cryptographic identity spine"

The identity callout survives as a centred mono strip between two foil rules:

```
  ────────────────────────────────
     did:nostr:<hex-pubkey>
  ────────────────────────────────
```

11px mono, `#ffd700`, 14px vertical padding.

Then six hairline rows, one per substrate — identity dot · name · role · chevron:

| Substrate | Role | Dot |
|---|---|---|
| VisionClaw | Knowledge engineering | `#00d4ff` |
| agentbox | Harness engineering | `#8b5cf6` |
| solid-pod-rs | Cryptographic foundation | `#10b981` |
| nostr-rust-forum | Governance UI + relay kit | `#f59e0b` |
| DreamLab Edge | Branded deployment | `#e94560` |
| Ontology Loom | Grounding & serving node | `#d4a574` |

**The big cut.** The shipped section carries 40 `<li>` bullets across six cards — CUDA kernel
counts, crate counts, NIP numbers, LOC figures. At 390px that is roughly 1,900px of scroll of
specification. The bullets are not deleted from the site; the row chevron routes to the
substrate's own detail, and the top-line claims survive in sections 04 and 08.

Closes with one line at Body: "The published corpus — 8,100+ pages under ODbL, compiled
losslessly into 286,533 triples — is the ontology in readable form." This is the shipped
`.callout` (a 240-word paragraph) reduced to its checkable facts.

---

## 04 — Guarantees

**Desktop source:** `#guarantees` · **Treatment:** full, re-ruled

H2: "Guarantees that hold at runtime"

Six **left-marked rows** — `2px solid #10b981` on the left, 16px padding, hairline below. Emerald
because the shipped `.ledger-card` already carries `border-left: 3px solid var(--emerald)`; the
mobile row is that border, minus the box.

All six titles and bodies are verbatim from the shipped `.ledger-card` markup:

1. Writes are gated, not hoped
2. Provenance you can query
3. The relay authenticates
4. Federation without a hub
5. The elevation loop closes
6. Action carries force

Plain voice uses `PANES` → `{ id: 'guarantees', sel: '.ledger-card p' }`, all six entries, which
are already written and matched in document order.

---

## 05 — Immersive

**Desktop source:** `#immersive` · **Treatment:** full

H2: "Walk through the knowledge graph"

Lead cut to: "Fifteen years of immersive data research at Salford's Centre for Virtual
Environments shaped VisionClaw's force-directed engine and its interaction design." The full
attribution (Dr John O'Hare's PhD, Prof Rob Aspin's CAVE infrastructure) is dropped from the
phone — it is a credential paragraph, and the photo caption already names the lab.

**Full-bleed photo well** — `img/showcase/cave-knowledge-graph.webp`, caption overlaid:

> **Octave Multimodal Lab** // University of Salford. Stereoscopic projection on walls and floor.

**Snap carousel**, four cards, from `.immersive-grid`:

| Card | Image |
|---|---|
| Stereoscopic data exploration | `octave-lab.webp` |
| Embodied interaction | `hand-interaction.webp` |
| Photogrammetry environments | `photogrammetry-env.webp` |
| Telecollaborative presence | `telepresence.webp` |

Card copy is the shipped copy cut to two sentences each. Plain voice from `PANES` →
`{ id: 'immersive', sel: '.immersive-card p' }`.

Closes with a quote rule: "**From CAVE to Quest 3.** Same binary protocol, same force-directed
physics, same `did:nostr` identity. The CAVE validated the concept at scale; the headset makes it
portable."

**Kept:** the featured `bottleneck.mp4` player and its `<details>` transcript disclosure, below
the closing line. It is 90 seconds and it is the best single artefact on the page.
**Dropped:** the two `.showcase-link` chips (THG world record video, repository) — they move to
the index's external links.

---

## 06 — Judgment Broker

**Desktop source:** `#broker` · **Treatment:** full

| Voice | H2 |
|---|---|
| Technical | Governance that accelerates, not blocks |
| Plain | AI prepares it. A person decides it. |

The plain H2 is a compression of `PLAIN.broker.title` ("Let AI prepare the decision; keep the
authority with people") — 25px at 390px gives it two lines either way, and the short form lands
harder. This is the one place a plain-voice string was rewritten; flag it if that's not wanted
and the original fits in three lines.

**Vertical timeline** (`COMPONENTS.md` §13), four steps:

| # | Step | Kind label |
|---|---|---|
| 1 | Agent declares | `31400 PANELDEFINITION · AGENTBOX` |
| 2 | Forum renders | `31402 ACTIONREQUEST · NOSTR-RUST-FORUM` |
| 3 | Human decides | `31403 ACTIONRESPONSE · NIP-98 SIGNED` |
| 4 | Knowledge gates | `VISIONCLAW` |

Closes with the embodied-loop callout, kept as a foil-bordered block:

```
  voice → intent → pod + KG → embodiment → elevation
```

11px mono at `#ffd700`, then two sentences of the shipped `.identity-callout` copy.

**Dropped:** the second identity callout (`agent → pod → 402 settle → anchor → did:nostr`) and
its payments paragraph. Stablecoins, HTTP 402 and taproot anchoring are a distinct argument that
deserves its own section rather than a footnote to governance — proposed as a 13th section if
wanted, otherwise it stays desktop-only.

---

## 07 — Economics

**Desktop source:** `#economic` · **Treatment:** condensed

H2: "Why deep token spend on hard problems is rational"

Four foil-ruled rows, each pairing a claim with its figure on the same baseline:

| Claim | Figure | Label |
|---|---|---|
| Cost of not coordinating | 5-8× | token waste from uncoordinated agent sprawl |
| Coordination as token multiplier | 3-5× | effective throughput gain from coordination |
| Hard problems justify deep spend | 10,000:1 | problem-value to token-cost ratio |
| Governance dividend | 90% | reduction in audit reconstruction cost |

Body copy is the shipped `.econ-card > p` cut to one sentence each; plain voice from `PANES` →
`{ id: 'economic', sel: '.econ-card > p' }`.

Closes with a quote rule: "Break-even is typically reached at three agents on any problem valued
above $50K."

**Dropped:** the ROI formula block. `ROI = (V × coordination_multiplier × governance_dividend) /
(token_cost × N)` is 62 characters of mono that cannot break and will not fit; it is also the
weakest evidence in the section, since none of its three multipliers is defined.

---

## 08 — Ontology Loom

**Desktop source:** `#loom` · **Treatment:** condensed
**Mesh:** the substrate helix figure binds here (unchanged from desktop).

H2: "The Ontology Loom: measured grounding behind a model-swappable façade"

Lead: "Held-out graph-derived benchmark on Qwen3.8-27B, across four grounding modes."

**The benchmark table** (`COMPONENTS.md` §14) — four rows, kept as a table:

| Mode | Recall | Note |
|---|---|---|
| Raw — no grounding | ~0.3 | Bare model on synthetic-corpus recall: near random |
| **Scaffold — static structured injection** | **~0.9** | The win — roughly 3× the baseline, from a pre-computed injection |
| Prose-enriched scaffold | ~0.9 | Adds ~nothing over structured; prose stays optional |
| Tools — agentic graph traversal | mid | Below static injection, and model-dependent |

Then the finding at Body: "The static structured scaffold is the whole win — roughly 3× the
baseline. Prose adds nothing; letting the model walk the graph tends to make it worse. The
scaffold, not the model, does the work, which is why the model can be a swappable URL."

Closes with the mono strip: `model = a URL behind a stable façade`.

**Dropped:** the three `.gap-card`s (confidence-aware injection, single read-truth, governed
elevation) and the "what the numbers measure" caveat. The caveat is load-bearing for honesty —
**it must appear somewhere**. Recommendation: keep it as a `<details>` disclosure labelled "What
the numbers measure", collapsed by default, directly under the table. Do not drop it silently.

---

## 09 — Case studies

**Desktop source:** `#cases` · **Treatment:** condensed

H2: "Federated problem-solving across trust boundaries"

**Snap carousel**, three cards, `flex: 0 0 280px`, foil-bordered. Emoji icons retained (🌍 💊 🎬)
— they are the shipped `.case-icon` and the only iconography on the page.

| Card | Copy |
|---|---|
| Climate modelling consortium | Shipped copy, cut to two sentences |
| Pharmaceutical drug discovery | Shipped copy, cut to two sentences |
| Creative production at scale | Shipped copy, cut to two sentences |

Plain voice from `PANES` → `{ id: 'cases', sel: '.case-card > p' }`.

**Dropped:** the three `.case-why` lines ("Why competitors can't:…"). They are the same argument
section 10 makes with evidence, three times over, without evidence.

**Kept:** `.validation-strip`, as three quote-ruled rows —

- **DreamLab Creative Hub** — 50-person team, 17,000+ graph nodes, daily production
- **University of Salford** — Research partnership, semantic force-directed layout
- **THG World Record** — 250+ concurrent XR users

---

## 10 — Landscape

**Desktop source:** `#competitive` · **Treatment:** full

H2: "Six axes. The field thins fast."

Compressed from "The frontier moved to coordination guarantees" + a 90-word lead. The lead's
argument (MCP and A2A standardised agent-to-agent talk; "having agents" is table stakes) is worth
keeping — recommendation: one sentence above the pips, "The industry standardised how agents
talk. The question now is who each actor is, who owns the data, and how decisions are governed."

**Six swipeable axis cards** (`COMPONENTS.md` §7), with a six-pip indicator above:

| # | Axis | Platforms scoring first-class |
|---|---|---|
| 01 | Crypto Identity | VisionFlow, Block Buzz, Fetch.ai |
| 02 | Data Sovereignty | VisionFlow, Block Buzz |
| 03 | Governance | VisionFlow, Block Buzz, Palantir AIP |
| 04 | Formal Reasoning | **VisionFlow only** |
| 05 | Federation | VisionFlow, Google A2A, Block Buzz, Fetch.ai |
| 06 | Open Source | all but Palantir AIP |

All eight platforms appear on every card, in the shipped row order, with their `.tbl-note`
qualifiers. Dot values are verbatim from the shipped `<table>` — no scores were re-judged.

Legend below. Closes with a quote rule: "Formal reasoning is the empty column. Only VisionFlow
carries all six at once — bound to one `did:nostr` key." (Compressed from the two `.gap-card`s.)

**Dropped:** the Block Buzz callout — 120 words on Jack Dorsey's team arriving independently at
the same substrate. It is the most interesting paragraph in the section and the least suited to
a phone. Recommendation: a `<details>` labelled "The closest convergence", under the legend.

---

## 11 — Scaling

**Desktop source:** `#scaling` · **Treatment:** condensed

H2: "Three axes, one architecture"

Three foil-ruled rows — tier eyebrow · title · body · cost line in italic Faint:

| Tier | Title |
|---|---|
| Single operator | Token-efficient |
| Team | Governed collaboration |
| Enterprise | Federated intelligence |

Copy verbatim from `.scale-card`, bodies cut to one sentence. The `.scale-card-mid` gold
highlight on "Team" is dropped — rule 1.

---

## 12 — Repositories

**Desktop source:** `#repos` · **Treatment:** condensed

H2: "Inspect, run, or replace every part"

Six hairline rows — name · description · tech line in mono Faint · chevron. Six, not eight: the
VisionFlow repo itself (the row reading "This repository") and `dreamlab-ai-website` are dropped;
one is circular on the phone, the other is a deployment of the kit rather than a substrate.

| Repo | Tech line |
|---|---|
| VisionClaw | OWL 2 EL · CUDA · XR · MCP |
| agentbox | Nix · 116 skills · Solid pods |
| solid-pod-rs | DID:Nostr · WAC · HTTP 402 |
| nostr-rust-forum | 14 crates · Leptos WASM |
| knowledgeGraph | 8,100+ pages · ODbL · WasmVOWL |
| loom | Model-swap façade · ~3× recall |

**Footer** follows: brand · one-line description · licence lines (`Code: AGPL-3.0 · Corpus:
ODbL-1.0 · Explorer: MIT`) · attribution. All verbatim. The three-column `.footer-links` block
(Ecosystem / Protocol / Licensing, 11 links) is dropped — its links live in the index.

---

## A — Index overlay

Triggered by ☰ in the nav. Full-screen, `z-index: 80`. See `COMPONENTS.md` §8.

Twelve numbered rows: The offer · Problem · Six substrates · Guarantees · Immersive · Judgment
Broker · Economics · Ontology Loom · Case studies · Landscape · Scaling · Repositories.

Below the foil divider, three external links: GitHub organisation · DreamLab AI ·
narrativegoldmine.com. Footer carries the "Talk to us" primary.

**State:** `isOpen: boolean`, local to the header. No new global state.

---

## B — Contact sheet

Triggered by the sticky bar or the index footer. Bottom sheet, `z-index: 71`. See
`COMPONENTS.md` §9.

- Title: "Talk to us"
- Lead: "Tell us the problem you can't coordinate. We reply from a `did:nostr` key, not a CRM."
- Field 1: Email — `you@organisation.org`
- Field 2: What are you trying to coordinate? — "Agents across three organisations, and no way to
  prove who approved what."
- Submit: "Send — NIP-17 gift-wrapped"
- Dismiss: "Not now"

**State:** `isOpen`, field values, `isSubmitting`. Validation and submission behaviour unchanged
from the existing DreamLab `EmailSignupForm` pattern — NIP-17 gift-wrapped DM, success only on
relay `OK: true`.

---

## Scroll budget

| Section | Approx. height at 390px |
|---|---|
| 01 The offer | 690px |
| 02 Problem | 810px |
| 03 Six substrates | 720px |
| 04 Guarantees | 800px |
| 05 Immersive | 900px |
| 06 Judgment Broker | 860px |
| 07 Economics | 820px |
| 08 Ontology Loom | 880px |
| 09 Case studies | 840px |
| 10 Landscape | 840px |
| 11 Scaling | 800px |
| 12 Repositories + footer | 840px |
| **Total** | **≈ 9,800px** |

The current mobile rendering of the same content is **≈ 22,400px**. The reduction is not
compression — it is the 40 substrate bullets, the eight-step evolution track, the five repeated
"why competitors can't" lines, the ROI formula and the desktop `py-16` rhythm.
