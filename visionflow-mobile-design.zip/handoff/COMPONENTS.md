# Components

Each component below gives its anatomy, exact values, states, and the repo selector it replaces.
All values are mobile-only (`max-width: 768px`). Colour names refer to `TOKENS.md`.

---

## 1. Nav bar

**Replaces** `.nav` / `.nav-inner` / `.nav-toggle` / `.nav-links` in `styles.css`.

| Part | Value |
|---|---|
| Height | 54px |
| Background | `rgba(10,10,13,.9)` + `backdrop-filter: blur(14px)` |
| Padding | `0 16px 0 20px` |
| Brand | `&#x25C8;` at `#ffd700` 1.15rem + "VisionFlow" 16/700/-.01em |
| Border | none — the progress bar below is the separator |

Contents, left to right: brand · reading switch · index toggle.

**Behaviour.** Always fixed, always opaque. The shipped `.nav.scrolled` state (transparent →
`rgba(14,14,17,.85)` at `scrollY > 50`) is dropped on mobile: the mesh is bright enough at the top
of the hero that a transparent bar makes the brand unreadable for the first 50px of every visit.

**Replaces the hamburger dropdown.** `.nav-links` at 768px currently becomes an absolutely
positioned column under the bar with nine links. That is replaced by the full-screen index (§8).

---

## 2. Progress bar

**New.** Sits directly under the nav, full-bleed.

| Part | Value |
|---|---|
| Track | 3px, `rgba(255,255,255,.05)` |
| Fill | `linear-gradient(90deg, #cd7f32, #ffd700, #d4a574)` |
| Transition | `width .1s linear` |

Width is `scrollTop / (scrollHeight - clientHeight)` as a percentage, rAF-throttled. It is the
only thing on the screen that tells you a 9,800px document is 20% done.

---

## 3. Progress rail

**New.** Pinned to the right edge, vertically centred, between the nav and the sticky bar.

| Part | Value |
|---|---|
| Column | 20px wide, `right: 6px`, `top: 60px`, `bottom: 96px` |
| Layout | `flex-direction: column; justify-content: center; gap: 7px` |
| Pip, idle | 2px × 8px, `rgba(255,255,255,.10)`, radius 2px |
| Pip, active | 2px × 18px, `linear-gradient(180deg, #ffd700, #cd7f32)` |
| Transition | `all .3s` |
| Pointer | `pointer-events: none` — decorative, not a control |

Twelve pips, one per section. The active pip is driven by the same IntersectionObserver as the
top bar (`threshold: 0.4`). This is why the right gutter is 40px and the left is 24px.

> If these are ever made tappable they must grow to a 44px hit area. As drawn they are
> non-interactive and exempt.

---

## 4. Reading switch

**Replaces** `#reading-switch` (the floating pill) in `styles.css` and its construction in
`initReadingSwitch()` in `main.js`.

| Part | Value |
|---|---|
| Layout | `Tech` label · knob · `Plain` label, `gap: 12px` |
| Labels | 10px mono, `.12em`, uppercase |
| Label, active | `#d4a574` |
| Label, idle | `rgba(240,237,237,.35)` |
| Track | 40 × 22px, radius 100px, `rgba(212,165,116,.12)`, border `1px rgba(212,165,116,.4)` |
| Knob | 16 × 16px, `linear-gradient(135deg, #ffd700, #cd7f32)`, `top: 2px` |
| Knob position | `left: 2px` (tech) → `left: 20px` (plain) |
| Transition | `left .35s cubic-bezier(.6,.05,.2,1)` — the shipped `.rl-thumb` easing |
| **Hit area** | **wrap in a 44 × 44px transparent button** |

**Behaviour.** Calls the existing `setMode(plain, animate)`. Persistence via
`localStorage['vf-reading']` is unchanged. On mobile `animate` is always `false` — the copy swaps
with a 200ms opacity crossfade instead of the 3D flip.

**Why it moved.** The floating pill sits bottom-right at `z-index: 60`, over the content it
controls, and at 390px it overlaps the sticky action bar's territory exactly. In the nav it is
visible at the moment the reader hits the first paragraph they don't understand — which is the
only moment it is useful.

---

## 5. Section header

**New pattern.** Opens every section 01–12.

```
┌──────────────────────────────┐
│  01   COORDINATION           │   ← numeral 52px, eyebrow 10px mono
│       ENGINEERING            │
│                              │
│  Federated Human–AI          │   ← H2 25/1.22/700
│  Intelligence                │
└──────────────────────────────┘
```

| Part | Value |
|---|---|
| Numeral | 52px/700, `line-height: .8`, gold gradient, `opacity: .5` |
| Eyebrow | 10px mono, `.2em`, uppercase, `#d4a574`, wraps to 2 lines |
| Layout | `display: flex; align-items: baseline; gap: 12px` |
| Numeral → H2 | 18–22px |
| H2 | 25/1.22/700/-.015em, `text-wrap: pretty` |

**Replaces** `.section-tag` (12px bottom margin, gold, `.12em`). The tag copy is reused verbatim
as the eyebrow; the numeral is new.

Implement the numeral as `section::before { content: attr(data-num) }` so it costs nothing on
desktop.

---

## 6. Ruled row

**The workhorse.** Replaces `.glass-card`, `.substrate-card`, `.case-card`, `.scale-card`,
`.econ-card`, `.gap-card`, `.ledger-card` and `.repo-card` wherever the content is a list item
rather than an object.

```
┌──────────────────────────────┐
│ ●  VisionClaw             →  │   ← dot 8px, title 17/600, chevron
│    KNOWLEDGE ENGINEERING     │   ← meta 9.5px mono
├──────────────────────────────┤
```

| Variant | Rule | Used in |
|---|---|---|
| Hairline | `1px rgba(255,255,255,.07)` bottom | 03 substrates, 04 guarantees, 12 repos |
| Foil | `1px rgba(212,165,116,.22)` top | 02 problem, 07 economics, 11 scaling |
| Left-marked | `2px solid #10b981` left, 16px padding-left | 04 guarantees |

| Part | Value |
|---|---|
| Vertical padding | 14–18px |
| Title | 17/1.35/600, Foreground |
| Second line | 14/1.55, Supporting |
| Meta line | 9.5px mono, `.12em`, uppercase, Muted |
| Identity dot | 8px circle, substrate colour, `box-shadow: 0 0 12px <colour>` |
| Chevron | `→`, Faint |
| Row height | 47–60px depending on lines |

The identity dot is the **only** place a substrate colour appears on mobile.

---

## 7. Swipeable axis card

**Replaces** `.competitive-table` + `.competitive-table-wrap` — an 8-row × 7-column matrix that
needs 700px of width inside a 390px frame.

The transform: **one card per capability axis**, each listing all eight platforms. Six cards,
horizontally snapped.

```
┌────────────────────────────┐ ┌───────────
│ 04                         │ │ 05
│ Formal Reasoning           │ │ Federation
├────────────────────────────┤ ├───────────
│ ● VisionFlow               │ │ ● VisionF
│ ● LangGraph                │ │ ● LangGra
│ …                          │ │ …
└────────────────────────────┘ └───────────
```

| Part | Value |
|---|---|
| Card | `flex: 0 0 300px`, radius 16px, padding 20px |
| Fill | `linear-gradient(155deg, rgba(212,165,116,.09), rgba(9,9,12,.6))` |
| Border | `1px rgba(212,165,116,.22)` |
| Axis numeral | 30px/700 gold gradient, `opacity: .55` |
| Axis name | 20/1.25/700 |
| Platform row | 14px, `padding: 9px 0`, top rule `rgba(255,255,255,.07)` |
| VisionFlow row | Foreground; all others Body |
| Dot | 9px circle — `#10b981` full · `#f59e0b` partial · `#e94560` absent |
| Track | `scroll-snap-type: x mandatory`, `gap: 14px`, `padding: 0 24px` |
| Scrollbar | hidden (`scrollbar-width: none`) |

**Pip indicator.** Six pips above the track, 3px tall, `flex: 1` each; the active one takes
`linear-gradient(90deg, #ffd700, #cd7f32)`. Driven by `round(scrollLeft / 314)`.

**Legend** stays below the track, unchanged copy: First-class / Partial / Absent.

The `.tbl-note` qualifiers (`framework`, `protocol`, `enterprise`) render as a 9px mono suffix on
each platform name — they are load-bearing for the argument and must not be dropped.

**Accessibility.** The track keeps `tabindex="0"` and the `aria-label` from
`.competitive-table-wrap`. Provide the full matrix as a visually-hidden `<table>` for screen
readers; the cards are a presentational transform of it.

---

## 8. Index overlay

**Replaces** the `.nav-links.open` dropdown.

| Part | Value |
|---|---|
| Surface | full-screen, `#0a0a0d`, opaque, `z-index: 80` |
| Header | 54px, brand left, `×` close right (44 × 44px, `#d4a574`, 22px) |
| Row | 56px, `border-bottom: 1px rgba(255,255,255,.07)` |
| Row number | 11px mono, `rgba(212,165,116,.7)`, 20px column |
| Row label | 19/600 |
| Row chevron | `→`, `rgba(240,237,237,.25)` |
| Divider | 2px `linear-gradient(90deg, #ffd700, #cd7f32, transparent)`, 24px above / 18px below |
| External links | 15px, Body, below the divider |
| Footer | "Talk to us" primary, 52px, 16/20/26px padding |

Twelve numbered rows, flat, no submenus. External links (GitHub org, DreamLab AI,
narrativegoldmine.com) sit below the foil divider — present but subordinate.

**Behaviour.** Tapping a row closes the overlay and smooth-scrolls to that section with a 54px
nav offset. Focus is trapped while open and returned to the toggle on close. `#main-content`
gets `inert`.

---

## 9. Contact sheet

**New.** The one primary action, per rule 3.

| Part | Value |
|---|---|
| Sheet | `#0e0e11`, radius `22px 22px 0 0`, `border-top: 1px rgba(212,165,116,.3)` |
| Shadow | `0 -20px 60px rgba(0,0,0,.6)` |
| Padding | `14px 24px 30px` |
| Grabber | 38 × 4px, `rgba(255,255,255,.16)`, radius 2px, centred, 18px below |
| Scrim | `rgba(10,10,13,.6)` + `blur(3px)`, `opacity` transition 250ms |
| Enter | `translateY(100% → 0)`, 340ms `cubic-bezier(.32,.72,0,1)` |
| Title | 22/1.25/700 |
| Lead | 15/1.55, Supporting |
| Field label | 10px mono, `.14em`, uppercase, Muted, 7px above the field |
| Field | 52px tall, **16px text**, radius 12px, fill `rgba(255,255,255,.03)`, border `1px rgba(255,255,255,.12)` |
| Field, focus | border `#d4a574`, no ring glow |
| Textarea | 3 rows, same treatment, `resize: none` |
| Submit | 52px, gold gradient, `#0e0e11` ink, 16/700 |
| Dismiss | 44px, text-only, Muted, "Not now" |

**Labels above fields, never placeholder-as-label.** Placeholders carry examples only.

**Behaviour.** Submission is unchanged from the existing DreamLab pattern — NIP-17 gift-wrapped
DM, success only on relay `OK: true`. Closes on scrim tap, `Escape`, "Not now", or successful
send. Opens from the sticky bar and from the index footer.

---

## 10. Sticky action bar

**New.**

| Part | Value |
|---|---|
| Container | `position: fixed; left/right/bottom: 0`, `z-index: 50` |
| Padding | `16px 20px 26px` (bottom includes safe area) |
| Fade | `linear-gradient(transparent, #0a0a0d 38%)` |
| Button | 52px, radius 12px, gold gradient, `#0e0e11` ink, 16/700 |
| Shadow | `0 8px 30px rgba(205,127,50,.35)` |
| Pointer | container `pointer-events: none`, button `pointer-events: auto` |

Every scrolling screen carries **130px** of bottom padding to clear it.

---

## 11. Photo well and carousel

**Replaces** `.showcase-hero` and `.immersive-grid` (which becomes `repeat(2, 1fr)` at 768px —
two 175px-wide cards with 4:3 images and three lines of body copy each).

**Hero well** — full-bleed, no radius on mobile, caption overlaid:

| Part | Value |
|---|---|
| Image | `width: 100%`, natural aspect |
| Caption | `padding: 18px 24px`, `linear-gradient(transparent, rgba(0,0,0,.88))` |
| Caption text | 14/1.5; `<strong>` at Foreground, rest at Body |

**Carousel** — four cards, horizontally snapped, bleeding off the right edge:

| Part | Value |
|---|---|
| Card | `flex: 0 0 244px`, radius 14px |
| Fill | `rgba(31,41,55,.35)`, border `1px rgba(255,255,255,.08)` |
| Image | `aspect-ratio: 4/3`, `object-fit: cover` |
| Body | padding 14px; title 15.5/1.3/600; copy 13.5/1.5 Supporting |
| Track | `gap: 12px`, `padding: 0 24px`, snap x mandatory |

This is the one place a card survives on mobile: a photograph needs a container, and four
photographs stacked vertically would add ~1,100px to the scroll.

---

## 12. Mesh backdrop

**Adapts** `website/static/js/mesh-webgl.js`. The brief is explicit: keep it live and
scroll-reactive, as on desktop.

| Parameter | Desktop | Mobile |
|---|---|---|
| Star count | current | 130 |
| Link threshold | current | 0.42 (distance in normalised space) |
| Link alpha | current | `(.20 - d * .3) × heroFade` |
| Node alpha | current | `.55 × heroFade × depth` |
| Hero fade | over `heroBot * .75` | over 620px of scroll |
| Y rotation | `t * 0.05` | `t * 0.06` |
| Spring | `1 - exp(-t*3)cos(t*7)` | same, **floored at 0.34** |
| Ontology figures | `#evolution`, `#loom` | `#substrates`, `#loom` |
| Figure gate | `W < 900` → hidden | shown; origin moves to `0.62 × W` |
| Figure spin | `prog * 2.2` | unchanged |
| `.mesh-label` | shown | hidden (already `display: none` below 900px) |
| `prefers-reduced-motion` | one settled frame, no rAF | identical |

**The spring floor matters.** `1 - exp(-t*3) * cos(t*7)` evaluates to exactly `0` at `t = 0`,
which multiplies the projection scale to zero and collapses all 130 points onto one pixel. On
desktop the next frame arrives 16ms later and nobody sees it; under reduced motion, or on the
single frame a paused tab paints, it is the whole backdrop. Floor it at `0.34`.

**The figure gate is the interesting change.** Line 242 of `mesh-webgl.js` reads
`if (f.top == null || W < 900) return;` — the scroll-driven ontology rings and substrate helix,
the site's best piece of eye candy, have never been seen on a phone. They were parked in the
right-hand dead space that `.section-figure`'s gradient creates on desktop, and that dead space
doesn't exist at 390px. Moving the origin to `0.62 × W` puts them behind the content instead,
where the section wash at `rgba(9,9,12,.86)` holds them at roughly 14% — present, legible,
never competing with the type.

---

## 13. Broker timeline

**Replaces** `.broker-flow` + `.broker-step` + `.broker-arrow`, which at 768px becomes a vertical
column with arrows `transform: rotate(90deg)` — four bordered boxes and three rotated arrows.

```
 ┃  Agent declares
 ●  31400 PANELDEFINITION · AGENTBOX
 ┃  The agent publishes a control panel…
 ┃
 ●  Forum renders
 ┃  31402 ACTIONREQUEST · NOSTR-RUST-FORUM
```

| Part | Value |
|---|---|
| Spine | 2px, `linear-gradient(180deg, #ffd700, #e94560)`, `left: 9px`, inset 8px top and bottom |
| Node | 12px circle, `#0a0a0d` fill, `2px solid #e94560` border |
| Content indent | 26px |
| Step title | 17/1.35/600 |
| Kind label | 9.5px mono, `.1em`, uppercase, `#e94560` |
| Step copy | 14/1.55, Supporting |
| Step gap | 22px |

**The kinds table dissolves into this.** `.broker-kinds` is a 6-row × 4-column table; four of its
rows (31400, 31402, 31403, and the VisionClaw gate) are already the four flow steps, so the kind
number and name become the step's mono label. The two remaining rows — `31401 PanelState` and
`31404 PanelUpdate` / `31405 PanelRetired` — are lifecycle events with no human-facing step; they
belong in the protocol docs, not on the marketing page's phone rendering.

---

## 14. Benchmark table

**Kept as a table** — the only one that survives. Four rows, three columns, no overflow.

| Part | Value |
|---|---|
| Row | `padding: 14px 12px`, top rule `rgba(255,255,255,.07)`, radius 8px |
| Mode | 15.5/1.35/600 |
| Note | 13/1.5, `rgba(240,237,237,.5)` |
| Recall | 18px mono/700, right-aligned |
| Highlighted row | fill `rgba(212,165,116,.10)`, mode at Foreground, recall at `#ffd700` |

The scaffold row (`~0.9`, "roughly 3× the baseline") is the highlighted one — it carries the
finding. Mirrors `.row-highlight` on desktop, in gold instead of crimson.

---

## 15. Emphasis block

**Replaces** `.callout` where the callout's job is a single number.

| Part | Value |
|---|---|
| Container | radius 14px, padding 20px |
| Fill | `linear-gradient(155deg, rgba(212,165,116,.10), rgba(9,9,12,.5))` |
| Border | `1px rgba(212,165,116,.25)` |
| Figure | 40px/700, gold gradient |
| Copy | 15/1.6, Body |

Used once per screen at most. Currently: the 73% shadow-adoption figure in section 02.

Where a callout is prose rather than a number, it becomes a **quote rule** instead: 15–19px at
Foreground, `padding-left: 16px`, `border-left: 2px solid #d4a574`. Used for the landscape
conclusion (10) and the economics break-even line (07).
