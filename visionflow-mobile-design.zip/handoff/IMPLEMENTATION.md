# Implementation

Target: `DreamLab-AI/VisionFlow`, branch `main`, path `website/`.
Stack: hand-written static HTML/CSS/JS. No framework, no bundler, no build step for the site
itself — `website/build.sh` copies `static/` to `dist/`, writes the CNAME, and pulls repo images.

**Read `TOKENS.md` §11 before starting.** It has the exact CSS to paste.

---

## Order of work

Each stage leaves the site shippable. Stages 1–3 are the ones that matter; if the work is
interrupted after stage 3 the mobile site is already substantially better.

### Stage 1 — The one-line fixes (30 min)

Highest value per character in the whole pack.

1. **`input, textarea, select { font-size: 16px }`** inside the new mobile media block. There is
   no `input.tsx` here — the fields are in `index.html` — but any field below 16px makes iOS zoom
   the viewport on focus and leaves the user pinched into a 130%-scaled page with no way back.
2. **`#bg-video { display: none }`** below 768px. A full-viewport `object-fit: cover` video
   decoding behind every scroll at `opacity: .28`.
3. **Spring floor in `mesh-webgl.js`** — `Math.max(0.34, 1 - Math.exp(-t*3) * Math.cos(t*7))`.
   Fixes a degenerate first frame that currently collapses the entire star field to one pixel
   under `prefers-reduced-motion` and on the first painted frame of every load.
4. **Nav offset on `scrollIntoView`.** `initSmoothScroll()` in `main.js` calls
   `target.scrollIntoView({ behavior: 'smooth', block: 'start' })`, which lands every section
   heading underneath the 64px fixed nav. Replace with an `offsetTop - navH` scroll.

> Note for whoever does this: `scrollIntoView` is being replaced for a layout reason, not a
> stylistic one. Don't reintroduce it.

### Stage 2 — Glass becomes rows (half a day)

Paste the `.glass-card, .substrate-card, .case-card, .scale-card, .econ-card, .gap-card,
.ledger-card` block from `TOKENS.md` §11 into the new media query. That one rule converts every
bordered box on the page into a hairline-separated row without touching a single line of HTML —
most of rule 2, for free.

Then the `:hover` neutralisation block. Touch devices have no hover; `hover:translateY(-3px)` and
`box-shadow: 0 12px 40px` are pure paint cost on a phone.

Verify at 390px: no card should have a visible border or a background fill except the immersive
carousel cards and the axis cards.

### Stage 3 — Chrome (1–2 days)

The nav, progress bar, rail, index overlay, sticky bar and contact sheet. All six are new markup
in `index.html` plus `initProgress()` and `initSheet()` in `main.js`. See `COMPONENTS.md` §1–3,
§8–10.

Do the reading switch move (`COMPONENTS.md` §4) in this stage: it is a nav component now.
`#reading-switch { display: none }` on mobile, bind `setMode()` to the new knob, keep everything
else in `initReadingSwitch()` untouched.

### Stage 4 — Section by section (3–5 days)

Work down `SCREENS.md` in order. Each section is independent; ship them as they land.

Sections 02, 04, 07, 11 and 12 are pure ruled-row conversions and go fast. Sections 05, 09 and 10
need the carousel and axis-card components built first. Section 06's timeline and section 08's
table are one-offs.

### Stage 5 — Mesh (1 day)

`mesh-webgl.js` node budget, figure gate and figure origin (`COMPONENTS.md` §12). Do this last:
it is the most visible change and the easiest to get wrong on a mid-range Android.

---

## File-by-file

### `website/static/css/styles.css`

- **Append** one `@media (max-width: 768px)` block after the existing one. Roughly 250 lines.
- **Do not edit** the existing 768px block. It is the reset the new block builds on.
- **Do not edit** `:root`. Every mobile token is additive and media-scoped.
- **Do not edit** the `prefers-reduced-motion` or `@media print` blocks.

### `website/static/index.html`

Six structural additions (`TOKENS.md` §11). No section is reordered; no section is deleted from
the markup — `#evolution` is hidden by CSS below 768px, so the desktop page is untouched and the
decision is one line to reverse.

Add `data-num="01"` … `data-num="12"` to the twelve sections and render the numeral via
`::before`, so desktop pays nothing for it.

### `website/static/js/main.js`

- `initReadingSwitch()` — skip the `makePanel()` height measurement and the `#reading-switch`
  append when mobile; bind to the nav knob. **Keep `PLAIN`, `PANES`, `setMode()` and the
  `localStorage['vf-reading']` line exactly as they are.**
- `initNavToggle()` — drive `#m-index` on mobile.
- `initSmoothScroll()` — nav offset.
- `initProgress()` — new. One IntersectionObserver at `threshold: 0.4` (the ratio
  `docs/DDD-website-context.md` already defines as "active") for the rail; one rAF-throttled
  scroll listener for the bar.
- `initSheet()` — new.
- `initScrollReveal()` — unchanged.
- `initBackgroundVideo()` — early-return on mobile.

Keep one source array for the twelve sections. The nav links, the index rows and the rail pips
are three renderings of the same list, and they will drift if they are three literals.

### `website/static/js/mesh-webgl.js`

Three changes inside `initMesh()`, all gated on `innerWidth <= 768`. See `COMPONENTS.md` §12.

The figure gate on line 242 (`if (f.top == null || W < 900) return;`) is the interesting one —
it has been hiding the ontology figures from every phone visitor since launch.

### `tests/site.spec.js`

Add a 390×844 project to `playwright.config.js` and assert: no horizontal overflow
(`scrollWidth === clientWidth` on `body`), the sticky bar is visible at every scroll position,
every field is ≥16px, and the index overlay traps focus. The existing desktop assertions stay.

---

## Risks

**The mesh on a mid-range Android.** 130 nodes and ~400 links is a guess tuned on a desktop
browser at 390px, not on a Pixel 6a. Profile it before shipping stage 5. If it costs more than
~4ms/frame, drop to 90 nodes before you drop the link threshold — the links are what make it read
as a mesh rather than a starfield. The `prefers-reduced-motion` branch already renders one
settled frame with no rAF; that is the floor and it is already correct.

**The reading switch is now a nav control with no explanation.** On desktop the floating pill is
large and labelled. A 40px knob marked Tech/Plain is discoverable only if you happen to look at
it. Consider a one-time coach mark on first visit, keyed to the same `localStorage` entry.

**`#evolution` is hidden, not deleted.** If anyone runs a link audit, `#evolution` is still a
valid anchor that scrolls to a `display: none` element on mobile. Either remove it from the
nav/index list on mobile (recommended — the index list is already mobile-specific) or unhide it.

**Three `<details>` disclosures are being proposed** (§08's "what the numbers measure", §10's
Block Buzz convergence, and the existing video transcript). Disclosures are where honest caveats
go to die. If the Loom caveat matters — and it does; it is the paragraph that says the corpus is
mostly synthetic — consider leaving it open by default on mobile.

**Copy sign-off.** `SCREENS.md` marks every trim. Two need a decision rather than a review: the
hero sub cut from 132 words to 32 (§01), and the plain-voice broker H2 rewritten from "Let AI
prepare the decision; keep the authority with people" to "AI prepares it. A person decides it."
(§06). Everything else is a cut, not a rewrite.

**Two sections were dropped whole** and need an explicit yes: the evolution line (§ README) and
the payments/`402 settle` callout (§06). Both are arguments the site makes nowhere else on
mobile.

---

## What NOT to touch

- **The desktop rendering.** Every change is inside `@media (max-width: 768px)` or gated on
  `innerWidth <= 768` in JS. Nothing above 769px moves.
- **`:root` in `styles.css`.**
- **`PLAIN` and `PANES` in `main.js`.** This copy is written, reviewed and shipped. The mobile
  design consumes it as-is; that is the whole reason the reading switch survives the port.
- **The `prefers-reduced-motion` block.** It is correct and already covers everything new.
- **`.mesh-label` and its `max-width: 900px` hide rule.** Projected HTML labels over a canvas on
  a 390px screen would be unreadable at any size that fits.
- **The `did:nostr` identity spine, the event kinds, the licence lines, the attribution.** Every
  number and every claim in this pack is copied from the repo. If a figure looks wrong, it is
  wrong in `index.html` too and should be fixed there first.
- **ADR-001 decisions 1 and 2.** They describe a Rust/WASM + Tailwind CDN stack that
  `website/build.sh` supersedes. Do not reintroduce either while doing this work. A follow-up
  ADR recording the static-CSS path as permanent would close the loop.

---

## Definition of done

- [ ] No horizontal scroll anywhere at 390px, 360px and 320px.
- [ ] No field below 16px.
- [ ] Every tap target ≥44×44px — including the reading switch, which is 40×22px in the mock and
      must be wrapped.
- [ ] Sticky bar visible and tappable at every scroll position; 130px of clearance everywhere.
- [ ] Index traps focus, closes on Escape, restores focus to the toggle.
- [ ] Contact sheet closes on scrim tap, Escape, "Not now", and successful send.
- [ ] The competitive matrix is reachable by screen reader as a real `<table>`.
- [ ] `prefers-reduced-motion` kills the mesh loop, the sheet transition and the copy crossfade.
- [ ] Desktop diff is zero — screenshot 1280px before and after.
- [ ] Total mobile scroll ≈9,800px, down from ≈22,400px.
