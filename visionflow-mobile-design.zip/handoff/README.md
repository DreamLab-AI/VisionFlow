# Handoff: VisionFlow mobile web surface

## Overview

`visionflow.info` is a single-page site that renders its desktop layout down to 390px through
one `@media (max-width: 768px)` block in `website/static/css/styles.css`. That block stacks the
grids and hides the scroll cue; everything else is the desktop page at phone width. The result
is fourteen sections of dense explanation delivered as: a full-viewport gradient-clipped hero,
eight glass cards in six accent hues, three tables that overflow horizontally by 130–310px, a
floating reading-level pill that sits on top of the content it controls, and a 4-step broker
flow rotated 90° with arrows that still point right.

This package redesigns the **mobile web surface only**. The desktop site is unchanged — nothing
here should alter rendering at 769px and above. Every colour, typeface and animation is
inherited from the shipped codebase; no new brand was invented.

The site is **hand-written static HTML/CSS/JS**. There is no framework, no bundler and no WASM,
despite what ADR-001 says — `website/build.sh` is authoritative:

> VisionFlow marketing site — pure static build. The site is hand-written HTML/CSS/JS with a
> self-contained WebGL2 mesh experience (static/js/mesh-webgl.js). No compile step, no bundler,
> no WASM.

ADR-001 decisions 1 (Rust/WASM modules) and 2 (Tailwind Play CDN) are both superseded in
implementation. Do not reintroduce either while doing this work.

## Source of truth

Values in this pack were read from, and must stay consistent with:

| File | What was taken from it |
|---|---|
| `website/static/css/styles.css` | every colour token, radius, type size, the 768px block |
| `website/static/index.html` | all section structure, all technical copy, all data tables |
| `website/static/js/main.js` | the `PLAIN` and `PANES` plain-English copy, reading-switch behaviour, IntersectionObserver reveal, nav scroll state |
| `website/static/js/mesh-webgl.js` | the hero star field, the ontology ring/helix figures, scroll-driven spin, the `W < 900` mobile bail-out |
| `website/build.sh` | build reality (supersedes ADR-001) |
| `docs/DDD-website-context.md` | Presentation/Animation/Content context boundaries |

The project root `github.md` maps each design screen to the repo files it was built from.

## The design files

`VisionFlow Mobile.dc.html` holds the work as a canvas of options, newest turn at the top:

| id | What it is |
|---|---|
| `2a` | **The specification.** Foil, built out — all twelve mobile sections, plus the index overlay and the contact sheet. This is what to implement. |
| `1a` | The current mobile rendering, recreated at 390px from source. Reference for what is being replaced. |
| `1b` | Ink & Rule — rejected direction. Glass deleted entirely, hairlines only. |
| `1c` | Lens — rejected direction. One thick glass panel as the reading surface. |
| `1d` | Foil — the direction, before build-out. Superseded by `2a`. |

These are **design references written in HTML**, not production code. Inline styles are an
artefact of the prototyping environment; the implementation belongs in `styles.css` as classes
inside a media block. Icon and photo slots use the real assets — `img/showcase/*.webp` already
exist in the repo.

## Fidelity

**High fidelity.** Colours, type scale, spacing, radii and touch targets are final and exact —
implement them as written in `TOKENS.md`. Copy is final: every string is either lifted verbatim
from `index.html` (technical voice) or from the `PLAIN`/`PANES` objects in `main.js` (plain
voice), with the trims noted per-section in `SCREENS.md`. No new copy was written.

## The five rules

Everything else follows from these. If a decision isn't covered by this pack, decide with these.

1. **Gold is the only accent that means "act".** The six substrate hues (cyan, purple, emerald,
   amber, crimson, gold) survive as 8px identity dots and nothing else. Crimson stays as the
   Judgment Broker's sequence colour and the "absent" dot. No card gets a coloured border.

2. **Rules, not walls.** At 390px a glass card is a box inside a box. `.glass-card`,
   `.substrate-card`, `.case-card`, `.scale-card` and `.econ-card` all become hairline-separated
   rows. Cards survive only where the thing genuinely is an object: a photo well, a swipeable
   axis, a case study you flick past.

3. **One primary action.** "Talk to us" in a sticky bottom bar that survives a 9,800px scroll.
   Everything else — GitHub, the repos, the corpus — is a text link in the index or the footer.

4. **Number the argument.** Fourteen sections is too many to hold in your head. Twelve numbered
   ones with 52px gold numerals, a right-edge rail and a top progress bar tell you where you are
   without a menu open.

5. **Say it once, at one reading level.** The Technical/Plain switch already exists and already
   has hand-written copy for every section. On mobile it moves into the nav, where it is visible
   at the moment you hit the first paragraph you don't understand.

## What changed structurally

Fourteen desktop sections become twelve mobile ones:

| # | Mobile section | Desktop source | Treatment |
|---|---|---|---|
| 01 | The offer | `#hero` | Rebuilt. Headline over stats; no full-viewport canvas. |
| 02 | Problem | `#problem` | Full. 4 glass cards → 4 ruled rows. |
| 03 | Six substrates | `#substrates` | Condensed. 6 cards with 40 bullets → 6 rows; bullets move to the substrate route. |
| 04 | Guarantees | `#guarantees` | Full, re-ruled. |
| 05 | Immersive | `#immersive` | Full. Hero photo + 4-card snap carousel. |
| 06 | Judgment Broker | `#broker` | Full. Flow becomes a vertical timeline; the 6-row kinds table folds into the step labels. |
| 07 | Economics | `#economic` | Condensed. Figure paired to claim; ROI formula dropped. |
| 08 | Ontology Loom | `#loom` | Condensed. The 4-row benchmark table survives as a table — the only one that does. |
| 09 | Case studies | `#cases` | Condensed to a snap carousel + validation rows. |
| 10 | Landscape | `#competitive` | Full. 8×6 matrix becomes 6 swipeable axis cards. |
| 11 | Scaling | `#scaling` | Condensed to three ruled tiers. |
| 12 | Repositories | `#repos` | Condensed to a ruled list. |
| — | **Evolution line** | `#evolution` | **Dropped below 768px.** See note. |

**On dropping `#evolution`:** it is an 8-step horizontal track that the current media query turns
into a vertical list of eight dots, plus two 200-word `.section-lead` paragraphs on the
ontology/knowledge-graph/grounding distinction. Vertically it is the single most expensive
section on the phone and it argues a point that sections 03 and 08 make concretely. Its scroll-
driven ring figure is preserved — it now animates behind section 03 (see `COMPONENTS.md`).
This is a recommendation, not a fait accompli: if the evolution narrative must stay, it belongs
as a 13th section between 02 and 03, and `SCREENS.md` has the layout for it.

## Interactions & behaviour

- **Index.** A full-screen overlay, flat, numbered 01–12, no submenus. Replaces the current
  dropdown, which renders as a 9-item stack under a 64px bar.
- **Progress.** A 3px gold gradient bar under the nav, plus a 12-pip rail pinned to the right
  edge. Both driven by the existing IntersectionObserver work in `main.js`.
- **Reading level.** Moves from the floating pill (`#reading-switch`, fixed bottom-right) into
  the nav as a 40px knob switch. Behaviour, copy and `localStorage['vf-reading']` persistence are
  unchanged. The 3D `rotateX(-180deg)` panel flip does **not** run on mobile — see `TOKENS.md` §10.
- **Tables.** The 8×6 competitive matrix becomes six horizontally-snapped axis cards, one per
  capability, each listing all eight platforms. The broker kinds table dissolves into its flow
  steps. The Loom benchmark stays a table — four rows, no horizontal overflow.
- **Mesh.** Stays live and scroll-reactive, per the brief. Node count, link threshold and the
  `W < 900` figure bail-out all change — see `COMPONENTS.md`.
- **Contact.** "Talk to us" opens a bottom sheet. Fields are 52px tall with 16px text; below 16px
  iOS zooms the viewport on focus.

## Assets

Nothing new is required.

- **Photography** — existing `website/static/img/showcase/*.webp` (`cave-knowledge-graph`,
  `octave-lab`, `hand-interaction`, `photogrammetry-env`, `telepresence`) and
  `img/vc-graph-hero.png`, `img/vc-control-center.png`.
- **Video** — `video/bottleneck.mp4` and `video/visionclaw.mp4` are referenced by `index.html`
  but are not in the repo (gitignored or added at deploy). The ambient `#bg-video` at 0.28 opacity
  is **dropped below 768px**; the featured `bottleneck.mp4` player stays.
- **Fonts** — unchanged. Inter 300–700 and JetBrains Mono 400/500, already loaded from Google
  Fonts in `index.html`.
- **Icons** — the site uses HTML entities (`&#x25C8;`, `&#x2B22;`, `&#x2716;`) and emoji for case
  studies. Unchanged. No icon library is introduced.

## Bundle contents

| File | What it is |
|---|---|
| `README.md` | This file — start here |
| `TOKENS.md` | Every design value, with the exact diff against `styles.css` |
| `COMPONENTS.md` | Each component: anatomy, values, states, and which repo selector it replaces |
| `SCREENS.md` | Each of the twelve sections plus the two overlays: layout, content, behaviour |
| `IMPLEMENTATION.md` | Order of work, file-by-file changes, risks, and what NOT to touch |
| `../VisionFlow Mobile.dc.html` | The designs, live |
