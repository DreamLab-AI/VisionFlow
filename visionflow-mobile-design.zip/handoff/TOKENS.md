# Design tokens

Every value below is either inherited verbatim from `website/static/css/styles.css` or a stated,
reasoned change to it. Hex values are exact — use them as written.

---

## 1. Where the current values come from

All from the `:root` block at the top of `styles.css` unless noted.

| Token | Value | Note |
|---|---|---|
| `--bg` | `#0e0e11` | page background |
| `--bg-dark` | `#0a0a0d` | footer, formula blocks |
| `--bg-card` | `rgba(31, 41, 55, 0.45)` | glass card fill |
| `--bg-glass` | `rgba(17, 24, 39, 0.6)` | callouts, identity callouts |
| `--text` | `#f0eded` | foreground |
| `--text-muted` | `#9ca3af` | body copy |
| `--text-dim` | `#8b95a5` | meta, captions |
| `--border` | `rgba(55, 65, 81, 0.4)` | every border on the site |
| `--bronze` | `#cd7f32` | |
| `--gold` | `#d4a574` | |
| `--bright-gold` | `#ffd700` | |
| `--crimson` | `#e94560` | broker sequence, "absent" dot, problem × marks |
| `--cyan` | `#00d4ff` | VisionClaw accent, callout left border |
| `--purple` | `#8b5cf6` | agentbox accent |
| `--emerald` | `#10b981` | solid-pod-rs accent, "first-class" dot, ledger left border |
| `--amber` | `#f59e0b` | nostr-rust-forum accent, "partial" dot |
| `--font` | `'Inter', system-ui, -apple-system, sans-serif` | |
| `--mono` | `'JetBrains Mono', ui-monospace, monospace` | |
| `--radius` | `12px` | |
| `--radius-sm` | `8px` | |
| Touch floor | `min-height: 44px; min-width: 44px` | `.nav-toggle` only — not a base rule |

---

## 2. Mobile surfaces

The mobile base moves from `--bg` `#0e0e11` to `--bg-dark` `#0a0a0d`. Both are already in the
palette. The darker base is chosen because the mesh canvas sits behind everything on mobile and
needs the extra contrast headroom; section washes then sit *above* the mesh rather than replacing
the page background.

| Name | Value | Use |
|---|---|---|
| Base | `#0a0a0d` | page background, behind the mesh canvas |
| Section wash | `rgba(9, 9, 12, 0.86)` | every section from 02 down; lets the mesh read at ~14% |
| Hero wash | `linear-gradient(180deg, rgba(9,9,12,0), rgba(9,9,12,.86) 12%)` | the 01→02 handover; the mesh is fully visible in 01 |
| Nav scrim | `rgba(10, 10, 13, 0.9)` + `backdrop-filter: blur(14px)` | sticky nav |
| Sheet | `#0e0e11` | contact bottom sheet |
| Overlay | `#0a0a0d` (opaque) | full-screen index |
| Sheet scrim | `rgba(10, 10, 13, 0.6)` + `blur(3px)` | behind the sheet |
| Raised | `rgba(212, 165, 116, 0.08)` over base | case cards, axis cards, the 73% block |
| Hairline | `rgba(255, 255, 255, 0.07)` | list rules inside a section |
| Foil rule | `rgba(212, 165, 116, 0.22)` | list rules that carry the gold argument (02, 07, 11) |
| Foil border | `rgba(212, 165, 116, 0.25)` | card borders, section-boundary rules |
| Field | `rgba(255, 255, 255, 0.03)` | input and textarea fill |
| Field border | `rgba(255, 255, 255, 0.12)` | input and textarea border |

**Replaces:** `--bg-card` `rgba(31,41,55,.45)` + `--border` `rgba(55,65,81,.4)` +
`backdrop-filter: blur(8px)` — the `.glass-card` treatment. Glass stays on desktop; on mobile it
becomes hairline-separated rows. The one survivor is the immersive carousel card, which keeps
`rgba(31,41,55,.35)` because a photo needs a container.

## 3. Text

| Name | Value | Use |
|---|---|---|
| Foreground | `#f0eded` | headings, list titles, highlighted table rows |
| Body | `rgba(240, 237, 237, 0.62)` | paragraphs, leads |
| Supporting | `rgba(240, 237, 237, 0.55)` | the second line of a ruled row |
| Muted | `rgba(240, 237, 237, 0.45)` | mono labels, footer copy |
| Faint | `rgba(240, 237, 237, 0.35)` | chevrons, counts, licence line |
| Rail idle | `rgba(240, 237, 237, 0.20)` | inactive progress pips |

Never below `.35` for anything carrying words. The shipped build uses `--text-dim` `#8b95a5`
(≈ `.55` equivalent) for meta and `--text-muted` `#9ca3af` for body; those map to Body and
Supporting above.

> **Known deviation in the mock.** `VisionFlow Mobile.dc.html` writes these alphas against
> `#FAFAFA` rather than the shipped `#f0eded` (e.g. `rgba(250,250,250,.62)`). The difference is
> under 2% luminance and invisible in situ, but implement against `#f0eded` so there is one
> foreground in the codebase.

## 4. Action

The shipped CTA is `linear-gradient(135deg, var(--gold), var(--bronze))` with `#0e0e11` ink
(`.btn-primary`). Mobile keeps it and adds a three-stop variant for the primary bar so the
52px button has somewhere to go.

| Name | Value | Use |
|---|---|---|
| Action | `linear-gradient(135deg, #ffd700, #d4a574, #cd7f32)` | primary button fill, sticky bar |
| Action (2-stop) | `linear-gradient(135deg, #d4a574, #cd7f32)` | secondary buttons, reading-switch knob |
| Action ink | `#0e0e11` | label on any gold fill |
| Action bright | `#ffd700` | numerals, figures, inline emphasis, active rail pip |
| Action mid | `#d4a574` | eyebrows, mono labels, active toggle label, icon strokes |
| Action tint | `rgba(212, 165, 116, 0.12)` | reading-switch track, callout fills |
| Action shadow | `0 8px 30px rgba(205, 127, 50, 0.35)` | sticky primary only |

**Contrast.** `#0e0e11` on `#d4a574` ≈ 9.6:1 (AAA). `#ffd700` on `#0a0a0d` ≈ 13.9:1 (AAA).
`rgba(240,237,237,.62)` on `#0a0a0d` ≈ 8.1:1 (AAA at body size). `#d4a574` on `#0a0a0d` ≈ 8.4:1.
The gold-gradient *text* used for numerals and figures is decorative-weight only — every such
string is a number that is also stated in adjacent prose or a mono label.

## 5. Inherited palette — identity and data only

Kept verbatim. Allowed as substrate identity dots, the broker sequence, matrix dots, and on
desktop. **Not** as card borders, icon tiles or section accents on mobile.

`#00d4ff` cyan (VisionClaw) · `#8b5cf6` purple (agentbox) · `#10b981` emerald (solid-pod-rs,
first-class) · `#f59e0b` amber (nostr-rust-forum, partial) · `#e94560` crimson (DreamLab Edge,
broker sequence, absent) · `#d4a574` gold (Ontology Loom)

## 6. Type

Stack unchanged: `Inter` for everything, `JetBrains Mono` for meta labels, numerals in tables,
and code strings. Both already loaded.

| Role | Size / line-height / weight / tracking | Notes |
|---|---|---|
| Section numeral | 52 / .8 / 700 / — | gold gradient at `opacity: .5`; decorative |
| Hero H1 | 36 / 1.08 / 700 / -.025em | was `clamp(2.5rem, 6vw, 4.5rem)` → 40px at 390px |
| Section H2 | 25 / 1.22 / 700 / -.015em | was `clamp(1.75rem, 4vw, 2.75rem)` → 28px at 390px |
| Card H3 | 20 / 1.25 / 700 | axis cards, case cards |
| Hero lead | 17 / 1.6 / 400 | at Body |
| Section lead | 16 / 1.65 / 400 | at Body; was `1.1rem` (17.6px) at `--text-muted` |
| List title | 17 / 1.35 / 600 | the first line of a ruled row |
| Supporting | 14 / 1.55 / 400 | at Supporting; the second line of a ruled row |
| Caption | 13.5 / 1.5 / 400 | photo captions, carousel body |
| Stat figure | 30 / 1 / 700 | gold gradient; hero stats |
| Emphasis figure | 40 / 1 / 700 | gold gradient; the 73% block |
| Metric figure | 26 / 1 / 700 | gold gradient; economics |
| Eyebrow | 10 mono / 1.4 / 500 / .2em, uppercase | at Action mid |
| Meta label | 9.5–10 mono / 1 / 500 / .12em, uppercase | at Muted |
| Mono inline | 11 mono / 1.6 / 500 | `did:nostr`, event kinds, formulas |
| Input text | **16** | hard floor — below this iOS zooms on focus |

All headings carry `text-wrap: pretty`. Body never below 13.5px except mono meta at 9.5px, which
never carries a sentence.

**Why the hero changed:** `clamp(2.5rem, 6vw, 4.5rem)` resolves to the 2.5rem floor at 390px, so
the phone gets the *smallest* heading in the system while also getting the longest one — the
shipped H1 is two lines of gradient-clipped text over a 132-word `.hero-sub`. 36/17 with the
sub cut to 32 words restores a 2.1 ratio and one clear first voice.

## 7. Spacing

Scale: `4 · 5 · 8 · 12 · 14 · 18 · 22 · 26 · 40 · 46`

| Role | Value | Was |
|---|---|---|
| Screen gutter, left | 24px | 24px (`.container`) — unchanged |
| Screen gutter, right | 40px | 24px — the extra 16px clears the progress rail |
| Full-bleed elements | 0 / 24px | carousels bleed right, pad left |
| Section rhythm | 40px | 64px (`.section` at 768px) |
| Hero block | 46px top / 44px bottom | 120px / 72px |
| Ruled row, vertical | 14–18px | card `padding: 28px` |
| Numeral → H2 gap | 18px | n/a |
| H2 → lead gap | 14px | 16px |
| Lead → content gap | 20–22px | 48px (`.section-lead`) |
| Bottom clearance | 130px | n/a — must clear the sticky bar |

## 8. Radius

| Role | Value |
|---|---|
| Buttons, inputs, textareas | 12px |
| Cards, media wells, callouts | 14px |
| Carousel and axis cards | 16px |
| Bottom sheet (top corners only) | 22px |
| Pills, dots, avatars, switch | 9999px |
| Progress pips and rails | 2px |

Replaces the shipped mix of 8px (`--radius-sm`), 12px (`--radius`) and 3px (`.broker-substrate`).

## 9. Targets

| Role | Value |
|---|---|
| Absolute minimum | 44×44px |
| Nav bar | 54px |
| Sticky primary button | 52px |
| Input / textarea row | 52px |
| Index menu row | 56px |
| Ruled list row | 47–60px |
| Sheet dismiss ("Not now") | 44px |
| Bottom bar block | 52 + 16 top + 26 bottom (safe area) = 94px |

> **Required fix at implementation.** The reading switch in the mock is a 40×22px knob — under
> the floor. Ship it with a transparent 44×44px hit area: keep the 40×22 visual, wrap it in a
> `button` with `padding: 11px 2px; min-height: 44px; min-width: 44px` and
> `background: transparent`. Same for the 12 rail pips if they are ever made tappable (they are
> decorative in this design and should stay `pointer-events: none`).

## 10. Motion

| Property | Value |
|---|---|
| Duration, state change | 200–350ms |
| Duration, sheet | 340ms |
| Easing, default | `ease-out` |
| Easing, sheet | `cubic-bezier(.32, .72, 0, 1)` |
| Easing, switch knob | `cubic-bezier(.6, .05, .2, 1)` — shipped `.rl-thumb` easing |
| Progress bar | `width .1s linear` |
| Animated properties | `color`, `background`, `border-color`, `opacity`, `transform: translate`, `width`, `height` |

**Kept on mobile:** the mesh canvas (see `COMPONENTS.md`), the `cueBob` scroll-cue bob, the
`fadeUp` hero entrance, and the `.reveal` IntersectionObserver fade.

**Dropped below 768px:**

| What | Where | Why |
|---|---|---|
| `.rl-inner { transform: rotateX(-180deg) }` | `styles.css` | The 3D panel flip measures and animates the height of every section intro on the page at once. On a phone it is a full-page reflow storm for an effect you cannot see end-to-end. The copy still swaps — instantly, with a 200ms opacity crossfade. |
| `#bg-video` at `opacity: .28` | `styles.css` | A full-viewport `object-fit: cover` video decoding behind every scroll, on cellular. |
| `.glass-card:hover { transform: translateY(-3px) }` | and every other `:hover` transform | No hover on touch; pure paint cost. |
| `.substrate-card:hover { box-shadow: 0 12px 40px }` | | as above |
| `.mesh-label` HTML label projection | `mesh-webgl.js` | Already `display: none` below 900px. Stays off. |
| `scroll-behavior: smooth` on `html` | `styles.css` | Keep, but see `IMPLEMENTATION.md` — `scrollIntoView` in `main.js` needs a nav-height offset. |

**`prefers-reduced-motion`** — the existing block in `styles.css` stays exactly as is. It already
kills every animation and transition, and `mesh-webgl.js` already renders one settled frame with
no rAF loop under it. The new mesh parameters must honour the same branch.

---

## 11. Diff against the codebase

### `website/static/css/styles.css`

Everything below goes in **one new `@media (max-width: 768px)` block appended after the existing
one**. Do not edit the existing block — it stays as the reset it already is.

```css
/* ── Mobile surface ───────────────────────────────────────────── */
@media (max-width: 768px) {
  :root {
    --m-base:        #0a0a0d;
    --m-wash:        rgba(9, 9, 12, 0.86);
    --m-hairline:    rgba(255, 255, 255, 0.07);
    --m-foil:        rgba(212, 165, 116, 0.22);
    --m-foil-2:      rgba(212, 165, 116, 0.25);
    --m-field:       rgba(255, 255, 255, 0.03);
    --m-body:        rgba(240, 237, 237, 0.62);
    --m-support:     rgba(240, 237, 237, 0.55);
    --m-muted:       rgba(240, 237, 237, 0.45);
    --m-faint:       rgba(240, 237, 237, 0.35);
    --m-action:      linear-gradient(135deg, #ffd700, #d4a574, #cd7f32);
    --m-gutter-l:    24px;
    --m-gutter-r:    40px;
    --m-rhythm:      40px;
    --radius:        12px;
  }

  body { background: var(--m-base); font-size: 16px; line-height: 1.65; }

  /* stop iOS zooming the viewport on field focus */
  input, textarea, select { font-size: 16px; }

  /* rule 2 — glass becomes rows */
  .glass-card,
  .substrate-card,
  .case-card,
  .scale-card,
  .econ-card,
  .gap-card,
  .ledger-card {
    background: transparent;
    backdrop-filter: none;
    -webkit-backdrop-filter: none;
    border: 0;
    border-bottom: 1px solid var(--m-hairline);
    border-radius: 0;
    padding: 16px 0;
  }
  .glass-card:hover,
  .substrate-card:hover,
  .case-card:hover,
  .scale-card:hover,
  .repo-card:hover { transform: none; box-shadow: none; }

  /* rule 1 — no coloured borders */
  .substrate-card { border-top: 0; }

  /* motion budget */
  .rl-inner { transform: none !important; transition: opacity .2s ease-out; }
  .rl-face  { position: static; backface-visibility: visible; }
  .rl-face-plain { transform: none; }
  .rl-face::before, .rl-face::after { display: none; }
  #bg-video { display: none; }

  /* the floating pill is replaced by the nav switch */
  #reading-switch { display: none; }

  /* section rhythm and rail clearance */
  .section { padding: var(--m-rhythm) 0; background: var(--m-wash); }
  .section-dark, .section-figure { background: var(--m-wash); }
  .container { padding: 0 var(--m-gutter-r) 0 var(--m-gutter-l); }

  /* drop the evolution section — see README */
  #evolution { display: none; }

  /* clear the sticky bar */
  .footer { padding-bottom: 130px; }
}
```

### `website/static/index.html`

Structural additions, all inside `<body>`:

1. **Nav** — add the reading switch and the index toggle to `.nav-inner`; add
   `<div class="m-progress"><span></span></div>` under it.
2. **Rail** — `<div class="m-rail" aria-hidden="true">` with twelve `<span>` pips, after `</nav>`.
3. **Index overlay** — `<div id="m-index" hidden>` with the twelve numbered rows. Built from the
   same list as `.nav-links`, so keep one source array in `main.js`.
4. **Sticky bar** — `<div class="m-bar"><button id="m-contact">Talk to us →</button></div>`
   before `</body>`.
5. **Contact sheet** — `<div id="m-sheet" hidden>` with the email + textarea + submit.
6. **Section numerals** — add `data-num="01"` … `data-num="12"` to each `<section>`; render via
   `::before` so desktop is untouched.

No section is reordered. No copy is rewritten.

### `website/static/js/main.js`

```js
const MOBILE = () => matchMedia('(max-width: 768px)').matches;
```

1. `initReadingSwitch()` — keep `PLAIN`, `PANES`, `setMode()` and the `localStorage` line
   verbatim. Skip `makePanel()`'s height measurement and skip appending `#reading-switch` when
   `MOBILE()`; bind `setMode` to the nav switch instead. The copy swap is the same function call.
2. `initNavToggle()` — when `MOBILE()`, drive `#m-index` (full-screen) instead of
   `.nav-links.open`. Trap focus; restore it to the toggle on close.
3. `initScrollReveal()` — unchanged; it already does the right thing.
4. **New** `initProgress()` — one `IntersectionObserver` over the twelve sections at
   `threshold: 0.4` (the ratio `DDD-website-context.md` already defines as "active") driving both
   the top bar width and the rail's active pip. One rAF-throttled `scroll` listener for the bar.
5. **New** `initSheet()` — open/close `#m-sheet`, scrim click, Escape, and `inert` on
   `#main-content` while open.
6. `initSmoothScroll()` — `scrollIntoView` currently lands section headings under the 64px fixed
   nav. Replace with `window.scrollTo({ top: el.offsetTop - navH, behavior: 'smooth' })`.

### `website/static/js/mesh-webgl.js`

Three changes, all inside `initMesh()`:

```js
const MOBILE = innerWidth <= 768;
const STAR_COUNT   = MOBILE ? 130 : /* current */ ;
const LINK_MAX_DIST = MOBILE ? 0.42 : /* current */ ;
```

1. **Node budget.** 130 nodes and a 0.42 link threshold on mobile.
2. **Figure gate.** Line 242 currently reads `if (f.top == null || W < 900) return;` — mobile
   never sees the ontology figures. Change to `if (f.top == null) return;` and reposition the
   figure origin to `FIG = [0.62 * W, ...]` on mobile so the rings sit behind the content rather
   than in a right-hand dead zone that doesn't exist at 390px. Rings bind to `#substrates` (the
   evolution section is gone); the helix stays on `#loom`.
3. **Spring floor.** The bounce term `1 - exp(-t*3) * cos(t*7)` is `0` at `t = 0`, which collapses
   every point to the origin on the first frame. Floor it: `Math.max(0.34, …)`. Harmless on
   desktop, and it means a paused or reduced-motion first frame shows the mesh rather than a dot.

### What NOT to change

- The `:root` block. Every mobile token is additive and scoped inside a media query.
- `--primary` / any desktop token. The desktop site is out of scope.
- The existing `@media (max-width: 768px)` block — it is the reset the new block builds on.
- The `prefers-reduced-motion` block. It is correct and already covers everything new.
- `@media print` — untouched.
- `PLAIN` and `PANES` in `main.js`. This copy is written, reviewed and shipped; the mobile design
  consumes it as-is.
- The `.mesh-label` projection and its `@media (max-width: 900px) { display: none }`.
