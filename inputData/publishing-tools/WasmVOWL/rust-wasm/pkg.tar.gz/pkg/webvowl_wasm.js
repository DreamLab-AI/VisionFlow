let wasm;

let cachedUint8ArrayMemory0 = null;

function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let WASM_VECTOR_LEN = 0;

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    }
}

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedDataViewMemory0 = null;

function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}
/**
 * Initialize panic hook for better error messages in WASM
 */
export function init() {
    wasm.init();
}

/**
 * Version information
 * @returns {string}
 */
export function version() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.version();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedFloat32ArrayMemory0 = null;

function getFloat32ArrayMemory0() {
    if (cachedFloat32ArrayMemory0 === null || cachedFloat32ArrayMemory0.byteLength === 0) {
        cachedFloat32ArrayMemory0 = new Float32Array(wasm.memory.buffer);
    }
    return cachedFloat32ArrayMemory0;
}

function passArrayF32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getFloat32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

const DebugFlagsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_debugflags_free(ptr >>> 0, 1));
/**
 * Debug configuration flags
 */
export class DebugFlags {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DebugFlagsFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_debugflags_free(ptr, 0);
    }
    /**
     * Enable all debug logging
     */
    enable_all() {
        wasm.debugflags_enable_all(this.__wbg_ptr);
    }
    /**
     * Check if logging should occur for this iteration
     * @param {number} iteration
     * @returns {boolean}
     */
    should_log(iteration) {
        const ret = wasm.debugflags_should_log(this.__wbg_ptr, iteration);
        return ret !== 0;
    }
    /**
     * Create new debug flags with default settings
     */
    constructor() {
        const ret = wasm.debugflags_new();
        this.__wbg_ptr = ret >>> 0;
        DebugFlagsFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Log force calculations
     * @returns {boolean}
     */
    get log_forces() {
        const ret = wasm.__wbg_get_debugflags_log_forces(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log force calculations
     * @param {boolean} arg0
     */
    set log_forces(arg0) {
        wasm.__wbg_set_debugflags_log_forces(this.__wbg_ptr, arg0);
    }
    /**
     * Log node positions
     * @returns {boolean}
     */
    get log_positions() {
        const ret = wasm.__wbg_get_debugflags_log_positions(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log node positions
     * @param {boolean} arg0
     */
    set log_positions(arg0) {
        wasm.__wbg_set_debugflags_log_positions(this.__wbg_ptr, arg0);
    }
    /**
     * Log node velocities
     * @returns {boolean}
     */
    get log_velocities() {
        const ret = wasm.__wbg_get_debugflags_log_velocities(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log node velocities
     * @param {boolean} arg0
     */
    set log_velocities(arg0) {
        wasm.__wbg_set_debugflags_log_velocities(this.__wbg_ptr, arg0);
    }
    /**
     * Log repulsion forces
     * @returns {boolean}
     */
    get log_repulsion() {
        const ret = wasm.__wbg_get_debugflags_log_repulsion(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log repulsion forces
     * @param {boolean} arg0
     */
    set log_repulsion(arg0) {
        wasm.__wbg_set_debugflags_log_repulsion(this.__wbg_ptr, arg0);
    }
    /**
     * Log attraction forces
     * @returns {boolean}
     */
    get log_attraction() {
        const ret = wasm.__wbg_get_debugflags_log_attraction(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log attraction forces
     * @param {boolean} arg0
     */
    set log_attraction(arg0) {
        wasm.__wbg_set_debugflags_log_attraction(this.__wbg_ptr, arg0);
    }
    /**
     * Log centering forces
     * @returns {boolean}
     */
    get log_centering() {
        const ret = wasm.__wbg_get_debugflags_log_centering(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log centering forces
     * @param {boolean} arg0
     */
    set log_centering(arg0) {
        wasm.__wbg_set_debugflags_log_centering(this.__wbg_ptr, arg0);
    }
    /**
     * Log Barnes-Hut calculations
     * @returns {boolean}
     */
    get log_barnes_hut() {
        const ret = wasm.__wbg_get_debugflags_log_barnes_hut(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Log Barnes-Hut calculations
     * @param {boolean} arg0
     */
    set log_barnes_hut(arg0) {
        wasm.__wbg_set_debugflags_log_barnes_hut(this.__wbg_ptr, arg0);
    }
    /**
     * Logging interval (log every N iterations)
     * @returns {number}
     */
    get log_interval() {
        const ret = wasm.__wbg_get_debugflags_log_interval(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Logging interval (log every N iterations)
     * @param {number} arg0
     */
    set log_interval(arg0) {
        wasm.__wbg_set_debugflags_log_interval(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) DebugFlags.prototype[Symbol.dispose] = DebugFlags.prototype.free;

const WebVowlFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_webvowl_free(ptr >>> 0, 1));
/**
 * Main WebVOWL WASM interface
 */
export class WebVowl {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WebVowlFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_webvowl_free(ptr, 0);
    }
    /**
     * Set simulation center
     * @param {number} x
     * @param {number} y
     */
    setCenter(x, y) {
        wasm.webvowl_setCenter(this.__wbg_ptr, x, y);
    }
    /**
     * Check if simulation is finished
     * @returns {boolean}
     */
    isFinished() {
        const ret = wasm.webvowl_isFinished(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Load ontology from JSON string
     * @param {string} json
     */
    loadOntology(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.webvowl_loadOntology(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get edge count
     * @returns {number}
     */
    getEdgeCount() {
        const ret = wasm.webvowl_getEdgeCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get graph data as JSON
     * @returns {any}
     */
    getGraphData() {
        const ret = wasm.webvowl_getGraphData(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get node count
     * @returns {number}
     */
    getNodeCount() {
        const ret = wasm.webvowl_getNodeCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get graph statistics
     * @returns {any}
     */
    getStatistics() {
        const ret = wasm.webvowl_getStatistics(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Run simulation for n iterations
     * @param {number} iterations
     */
    runSimulation(iterations) {
        const ret = wasm.webvowl_runSimulation(this.__wbg_ptr, iterations);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Initialize the force simulation
     */
    initSimulation() {
        const ret = wasm.webvowl_initSimulation(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Check which node (if any) is clicked by a ray from the camera
     *
     * This method performs ray-sphere intersection testing to determine
     * which node was clicked in 3D space.
     *
     * # Arguments
     * * `ray_origin` - Ray origin as [x, y, z] array
     * * `ray_direction` - Ray direction as [x, y, z] array (will be normalized)
     *
     * # Returns
     * * `Some(node_id)` - ID of the closest clicked node
     * * `None` - No node was clicked
     *
     * # Example (from JavaScript)
     * ```javascript
     * const nodeId = webvowl.checkNodeClick(
     *     [0, 0, 10],  // Camera position
     *     [0, 0, -1]   // Looking down -Z axis
     * );
     * if (nodeId) {
     *     console.log(`Clicked node: ${nodeId}`);
     * }
     * ```
     *
     * # Performance
     * This method is optimized for graphs with up to 1,000 nodes.
     * For larger graphs, it should still complete in < 1ms on modern hardware.
     * @param {Float32Array} ray_origin
     * @param {Float32Array} ray_direction
     * @returns {string | undefined}
     */
    checkNodeClick(ray_origin, ray_direction) {
        const ptr0 = passArrayF32ToWasm0(ray_origin, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayF32ToWasm0(ray_direction, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.webvowl_checkNodeClick(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        let v3;
        if (ret[0] !== 0) {
            v3 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v3;
    }
    /**
     * Set link distance
     * @param {number} distance
     */
    setLinkDistance(distance) {
        wasm.webvowl_setLinkDistance(this.__wbg_ptr, distance);
    }
    /**
     * Set charge strength
     * @param {number} strength
     */
    setChargeStrength(strength) {
        wasm.webvowl_setChargeStrength(this.__wbg_ptr, strength);
    }
    /**
     * Create a new WebVOWL instance
     */
    constructor() {
        const ret = wasm.webvowl_new();
        this.__wbg_ptr = ret >>> 0;
        WebVowlFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Perform one simulation tick
     */
    tick() {
        const ret = wasm.webvowl_tick(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get current alpha value
     * @returns {number}
     */
    getAlpha() {
        const ret = wasm.webvowl_getAlpha(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WebVowl.prototype[Symbol.dispose] = WebVowl.prototype.free;

const EXPECTED_RESPONSE_TYPES = new Set(['basic', 'cors', 'default']);

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);

            } catch (e) {
                const validResponse = module.ok && EXPECTED_RESPONSE_TYPES.has(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else {
                    throw e;
                }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);

    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };

        } else {
            return instance;
        }
    }
}

function __wbg_get_imports() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbg_Error_e83987f665cf5504 = function(arg0, arg1) {
        const ret = Error(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_String_8f0eb39a4a4c2f66 = function(arg0, arg1) {
        const ret = String(arg1);
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg___wbindgen_throw_b855445ff6a94295 = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbg_groupEnd_797dfd00422bd255 = function() {
        console.groupEnd();
    };
    imports.wbg.__wbg_group_f93d88decc5aa51c = function(arg0) {
        console.group(arg0);
    };
    imports.wbg.__wbg_log_8cec76766b8c0e33 = function(arg0) {
        console.log(arg0);
    };
    imports.wbg.__wbg_new_1acc0b6eea89d040 = function() {
        const ret = new Object();
        return ret;
    };
    imports.wbg.__wbg_new_e17d9f43105b08be = function() {
        const ret = new Array();
        return ret;
    };
    imports.wbg.__wbg_set_3f1d0b984ed272ed = function(arg0, arg1, arg2) {
        arg0[arg1] = arg2;
    };
    imports.wbg.__wbg_set_c213c871859d6500 = function(arg0, arg1, arg2) {
        arg0[arg1 >>> 0] = arg2;
    };
    imports.wbg.__wbg_warn_1d74dddbe2fd1dbb = function(arg0) {
        console.warn(arg0);
    };
    imports.wbg.__wbindgen_cast_2241b6af4c4b2941 = function(arg0, arg1) {
        // Cast intrinsic for `Ref(String) -> Externref`.
        const ret = getStringFromWasm0(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbindgen_cast_4625c577ab2ec9ee = function(arg0) {
        // Cast intrinsic for `U64 -> Externref`.
        const ret = BigInt.asUintN(64, arg0);
        return ret;
    };
    imports.wbg.__wbindgen_cast_d6cd19b81560fd6e = function(arg0) {
        // Cast intrinsic for `F64 -> Externref`.
        const ret = arg0;
        return ret;
    };
    imports.wbg.__wbindgen_init_externref_table = function() {
        const table = wasm.__wbindgen_externrefs;
        const offset = table.grow(4);
        table.set(0, undefined);
        table.set(offset + 0, undefined);
        table.set(offset + 1, null);
        table.set(offset + 2, true);
        table.set(offset + 3, false);
        ;
    };

    return imports;
}

function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    __wbg_init.__wbindgen_wasm_module = module;
    cachedDataViewMemory0 = null;
    cachedFloat32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;


    wasm.__wbindgen_start();
    return wasm;
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (typeof module !== 'undefined') {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();

    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }

    const instance = new WebAssembly.Instance(module, imports);

    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (typeof module_or_path !== 'undefined') {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (typeof module_or_path === 'undefined') {
        module_or_path = new URL('webvowl_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync };
export default __wbg_init;
