/* tslint:disable */
/* eslint-disable */
/**
 * Initialize panic hook for better error messages in WASM
 */
export function init(): void;
/**
 * Version information
 */
export function version(): string;
/**
 * Debug configuration flags
 */
export class DebugFlags {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Enable all debug logging
   */
  enable_all(): void;
  /**
   * Check if logging should occur for this iteration
   */
  should_log(iteration: number): boolean;
  /**
   * Create new debug flags with default settings
   */
  constructor();
  /**
   * Log force calculations
   */
  log_forces: boolean;
  /**
   * Log node positions
   */
  log_positions: boolean;
  /**
   * Log node velocities
   */
  log_velocities: boolean;
  /**
   * Log repulsion forces
   */
  log_repulsion: boolean;
  /**
   * Log attraction forces
   */
  log_attraction: boolean;
  /**
   * Log centering forces
   */
  log_centering: boolean;
  /**
   * Log Barnes-Hut calculations
   */
  log_barnes_hut: boolean;
  /**
   * Logging interval (log every N iterations)
   */
  log_interval: number;
}
/**
 * Main WebVOWL WASM interface
 */
export class WebVowl {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Set simulation center
   */
  setCenter(x: number, y: number): void;
  /**
   * Check if simulation is finished
   */
  isFinished(): boolean;
  /**
   * Load ontology from JSON string
   */
  loadOntology(json: string): void;
  /**
   * Get edge count
   */
  getEdgeCount(): number;
  /**
   * Get graph data as JSON
   */
  getGraphData(): any;
  /**
   * Get node count
   */
  getNodeCount(): number;
  /**
   * Get graph statistics
   */
  getStatistics(): any;
  /**
   * Run simulation for n iterations
   */
  runSimulation(iterations: number): void;
  /**
   * Initialize the force simulation
   */
  initSimulation(): void;
  /**
   * Check which node (if any) is clicked by a ray from the camera
   *
   * This method performs ray-sphere intersection testing to determine
   * which node was clicked in 3D space.
   *
   * # Arguments
   * * `ray_origin` - Ray origin as [x, y, z] array
   * * `ray_direction` - Ray direction as [x, y, z] array (will be normalized)
   *
   * # Returns
   * * `Some(node_id)` - ID of the closest clicked node
   * * `None` - No node was clicked
   *
   * # Example (from JavaScript)
   * ```javascript
   * const nodeId = webvowl.checkNodeClick(
   *     [0, 0, 10],  // Camera position
   *     [0, 0, -1]   // Looking down -Z axis
   * );
   * if (nodeId) {
   *     console.log(`Clicked node: ${nodeId}`);
   * }
   * ```
   *
   * # Performance
   * This method is optimized for graphs with up to 1,000 nodes.
   * For larger graphs, it should still complete in < 1ms on modern hardware.
   */
  checkNodeClick(ray_origin: Float32Array, ray_direction: Float32Array): string | undefined;
  /**
   * Set link distance
   */
  setLinkDistance(distance: number): void;
  /**
   * Set charge strength
   */
  setChargeStrength(strength: number): void;
  /**
   * Create a new WebVOWL instance
   */
  constructor();
  /**
   * Perform one simulation tick
   */
  tick(): void;
  /**
   * Get current alpha value
   */
  getAlpha(): number;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_debugflags_free: (a: number, b: number) => void;
  readonly __wbg_get_debugflags_log_attraction: (a: number) => number;
  readonly __wbg_get_debugflags_log_barnes_hut: (a: number) => number;
  readonly __wbg_get_debugflags_log_centering: (a: number) => number;
  readonly __wbg_get_debugflags_log_forces: (a: number) => number;
  readonly __wbg_get_debugflags_log_interval: (a: number) => number;
  readonly __wbg_get_debugflags_log_positions: (a: number) => number;
  readonly __wbg_get_debugflags_log_repulsion: (a: number) => number;
  readonly __wbg_get_debugflags_log_velocities: (a: number) => number;
  readonly __wbg_set_debugflags_log_attraction: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_barnes_hut: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_centering: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_forces: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_interval: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_positions: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_repulsion: (a: number, b: number) => void;
  readonly __wbg_set_debugflags_log_velocities: (a: number, b: number) => void;
  readonly __wbg_webvowl_free: (a: number, b: number) => void;
  readonly debugflags_enable_all: (a: number) => void;
  readonly debugflags_new: () => number;
  readonly debugflags_should_log: (a: number, b: number) => number;
  readonly init: () => void;
  readonly version: () => [number, number];
  readonly webvowl_checkNodeClick: (a: number, b: number, c: number, d: number, e: number) => [number, number];
  readonly webvowl_getAlpha: (a: number) => number;
  readonly webvowl_getEdgeCount: (a: number) => number;
  readonly webvowl_getGraphData: (a: number) => [number, number, number];
  readonly webvowl_getNodeCount: (a: number) => number;
  readonly webvowl_getStatistics: (a: number) => [number, number, number];
  readonly webvowl_initSimulation: (a: number) => [number, number];
  readonly webvowl_isFinished: (a: number) => number;
  readonly webvowl_loadOntology: (a: number, b: number, c: number) => [number, number];
  readonly webvowl_new: () => number;
  readonly webvowl_runSimulation: (a: number, b: number) => [number, number];
  readonly webvowl_setCenter: (a: number, b: number, c: number) => void;
  readonly webvowl_setChargeStrength: (a: number, b: number) => void;
  readonly webvowl_setLinkDistance: (a: number, b: number) => void;
  readonly webvowl_tick: (a: number) => [number, number];
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
