import asyncio
import os
import re
import edge_tts

class TTSProcessorNode:
    def __init__(self):
        self.output_directory = "dialogue_lines_output_v3"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "triggerStatus": ("STRING", {"default": "", "description": "Trigger to start processing"}),
            },
            "optional": {
                "inputDirectory": ("STRING", {"default": "dialogue_lines_output_v3", "description": "Directory containing dialogue line text files."}),
                "outputDirectory": ("STRING", {"default": "tts_output", "description": "Output directory for TTS audio files."})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("ProcessingStatus",)
    FUNCTION = "process_text_to_audio"
    CATEGORY = "Audio/TTS Processing"

    async def generate_tts(self, text, voice, output_path):
        # This is a placeholder for your TTS generation logic.
        # Use edge_tts or any other library here to generate TTS and save to `output_path`.
        tts = edge_tts.Communicate(text=text, voice=voice)
        await tts.save(output_path)

    def process_text_to_audio(self, triggerStatus, inputDirectory=None, outputDirectory=None):
        if not inputDirectory:
            inputDirectory = self.output_directory
        if not os.path.exists(inputDirectory):
            return "Input directory does not exist."

        if not outputDirectory:
            outputDirectory = "tts_output"
        if not os.path.exists(outputDirectory):
            os.makedirs(outputDirectory)

        files = os.listdir(inputDirectory)
        files.sort(key=lambda x: int(re.search(r'(\d+)', x).group()))

        # Set up event loop
        try:
            loop = asyncio.get_event_loop()
            if loop.is_closed():
                raise RuntimeError("Event loop is closed")
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        tasks = []
        for file in files:
            path = os.path.join(inputDirectory, file)
            with open(path, 'r') as f:
                line = f.read().strip()
                # Determine the voice based on the file naming convention
                voice = "en-US-JennyNeural" if '_woman' in file else "en-US-GuyNeural"
                if '_unknown' in file:
                    voice = "en-US-SteffanNeural"
                output_path = os.path.join(outputDirectory, f"{os.path.splitext(file)[0]}.mp3")
                tasks.append(self.generate_tts(line, voice, output_path))

        # Run TTS generation tasks
        loop.run_until_complete(asyncio.gather(*tasks))
        loop.close()

        return "Processed all text files to audio."

# Node registration for ComfyUI
NODE_CLASS_MAPPINGS = {
    "TTSProcessorNode": TTSProcessorNode,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "TTSProcessorNode": "TTS Line Processor",
}
