import os
import re
from datetime import datetime
from moviepy.editor import concatenate_audioclips, AudioFileClip

class AudioCombinerNode:
    def __init__(self):
        self.input_directory = os.path.join(os.getcwd(), "audio_output")
        self.output_directory = os.path.join(os.getcwd(), "combined_audio")
        os.makedirs(self.output_directory, exist_ok=True)

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "trigger": ("STRING", {"default": "", "description": "Dummy trigger input to start the process"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("StatusMessage",)
    FUNCTION = "combine_audio"
    CATEGORY = "Audio/Combining"
    DESCRIPTION = "Combines audio files in the 'audio_output' directory into one audio file in the 'combined_audio' directory in sequential order, adding a timestamp to the filename."

    def combine_audio(self, trigger):
        try:
            audio_files = [f for f in os.listdir(self.input_directory) if f.endswith('.mp3')]
            audio_files.sort(key=lambda x: int(re.search(r'(\d+)_', x).group(1)))

            clips = [AudioFileClip(os.path.join(self.input_directory, f)) for f in audio_files]
            combined_clip = concatenate_audioclips(clips)

            # Generate a timestamp for the output filename
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            outputAudioPath = os.path.join(self.output_directory, f"combined_audio_{timestamp}.mp3")

            combined_clip.write_audiofile(outputAudioPath)
            return f"Audio successfully combined and saved to {outputAudioPath}",

        except Exception as e:
            return f"Error combining audio files: {str(e)}",

# Node registration for ComfyUI
NODE_CLASS_MAPPINGS = {
    "AudioCombinerNode": AudioCombinerNode,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "AudioCombinerNode": "Audio Combiner",
}
