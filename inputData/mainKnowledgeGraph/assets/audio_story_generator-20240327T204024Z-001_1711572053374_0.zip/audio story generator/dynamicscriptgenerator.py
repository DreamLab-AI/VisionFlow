# so the (1,2,3,x) in scene means first number is is there narration, so 1 or 0, second line means number 
# of actor 1 lines, second actor 2 lines and so forth, the genre is not used. the actor names are seperated by comma and 
# there has to be empty line before the name. description is supposed to be used to create image. 

import openai
import random

class ScriptGenerator:
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "scenes": ("STRING", {"default": "FOREST (1,2,2), FIELD (0,3,1)", "description": "Comma-separated scene names with details in parentheses, indicating the number of narrator and actor lines respectively."}),
                "era": ("STRING", {"default": "1960s - Swinging Sixties"}),
                "names": ("STRING", {"default": "Alice, Bob", "description": "Comma-separated character first names"}),
                "characterDescriptions": ("STRING", {"default": "Alice=(description), Bob=(description)", "description": "Comma-separated character descriptions, matched to names"}),
                "model": ("STRING", {"default": "gpt-3.5-turbo", "description": "The AI model name for script generation"}),
                "genre": ("STRING", {"default": "comedy", "description": "Genre of the script"}),
            },
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "STRING")
    RETURN_NAMES = ("scriptFilePath", "characterDescriptionFilePath", "scriptContent", "characterDescriptionContent")
    FUNCTION = "generate_and_fill_script"
    CATEGORY = "Text/AI Script Generation"

    def generate_and_fill_script(self, scenes, era, names, characterDescriptions, model, genre):
        scenes_details = self._parse_scenes_details(scenes)
        names_list = names.split(", ")
        characterDescriptions_dict = dict(item.split("=") for item in characterDescriptions.split(", "))
        
        characterDescriptionFilePath = "characterDescription.txt"
        characterDescriptionContent = "\n".join(f"{name}={description}" for name, description in characterDescriptions_dict.items())
        with open(characterDescriptionFilePath, "w") as file:
            file.write(characterDescriptionContent)

        proceduralScript = self._generate_procedural_script(scenes_details, era, names_list)
        proceduralScriptFilePath = "proceduralScriptWithPlaceholders.txt"
        with open(proceduralScriptFilePath, "w") as file:
            file.write(proceduralScript)

        filledScript = self._fill_script_with_ai(proceduralScript, model, genre)
        scriptFilePath = "script.txt"
        with open(scriptFilePath, "w") as file:
            file.write(filledScript)

        return scriptFilePath, characterDescriptionFilePath, filledScript, characterDescriptionContent

    def _parse_scenes_details(self, scenes):
        scenes_details = []
        for scene_detail in scenes.split(", "):
            parts = scene_detail.split(" ")
            scene_name = parts[0]
            details = eval("".join(parts[1:]))
            scenes_details.append((scene_name, details))
        return scenes_details

    def _generate_procedural_script(self, scenes_details, era, names):
        script_lines = []
        for scene_name, details in scenes_details:
            scene_lines = [f"((Scene: {scene_name} in the {era}))"]
            narrator_count, actor_lines_details = details[0], details[1:]

            if narrator_count >= 1:
                scene_lines.append("#narrator: [Introductory narration]")  # Introductory narration

            # Actor lines shuffled
            actor_lines_pool = [f"#{name}: [Actor's line]" for name, count in zip(names, actor_lines_details) for _ in range(count)]
            random.shuffle(actor_lines_pool)
            scene_lines.extend(actor_lines_pool)

            if narrator_count == 2:
                scene_lines.append("#narrator: [Concluding narration]")  # Concluding narration

            script_lines.extend(scene_lines)

        return "\n".join(script_lines)

    def _fill_script_with_ai(self, proceduralScript, model, genre):
        openai.api_base = "http://localhost:1234/v1"
        prompt = (
              "This is a procedurally generated script that needs to be filled with engaging dialogue and scene descriptions. "
              "Each actor line is marked by the actor's name followed by a colon and placeholder text within square brackets. "
              "Replace only the placeholder text within the square brackets with appropriate dialogue that fits the context of the scene. "
              "Do not alter the scene descriptions, actor names, or any text outside the square brackets. "
              "Make sure the new dialogue maintains the narrative flow and matches the tone and setting of each scene. "
              "Here is the script:\n\n"
               f"{proceduralScript}\n"
               "Please fill in the actor lines and scene descriptions, making the script come to life."
        )
        try:
            response = openai.Completion.create(
                model=model,
                prompt=prompt,
                temperature=0.7,
                max_tokens=2048,
                stop=["\n\n"]
            )
            return response.choices[0].text.strip()
        except Exception as e:
            print(f"Error generating filled script: {e}")
            return "Error generating script."

# Node registration for ComfyUI
NODE_CLASS_MAPPINGS = {
    "ScriptGenerator": ScriptGenerator,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "ScriptGenerator": "Dynamic Script Generator",
}

