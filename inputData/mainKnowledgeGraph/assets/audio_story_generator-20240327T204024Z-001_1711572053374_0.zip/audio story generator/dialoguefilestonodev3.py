import os
import re

class DialogueLinesToFileNodeV3:
    def __init__(self):
        # Specifies the output directory for dialogue lines text files.
        self.output_directory = "dialogue_lines_output_v3"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "scriptText": ("STRING", {"default": "", "multiline": True, "description": "The full script text including actor and narrator lines, excluding scene descriptions."}),
                "characterDescriptions": ("STRING", {"default": "", "multiline": True, "description": "Character descriptions in format Name=(description with gender marker)."}),
            },
            "optional": {
                "outputDirectory": ("STRING", {"default": "dialogue_lines_output_v3", "description": "Output directory for dialogue lines text files."})
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("StatusMessage",)
    FUNCTION = "process_dialogue_lines_v3"
    CATEGORY = "Text/Audio Processing"
    DESCRIPTION = "Extracts dialogue lines from a script and saves them as separate text files, named according to the actor and the order of their lines."

    def process_dialogue_lines_v3(self, scriptText, characterDescriptions, outputDirectory=None):
        if not outputDirectory:
            outputDirectory = self.output_directory
        if not os.path.exists(outputDirectory):
            os.makedirs(outputDirectory)

        gender_map = self._parse_character_descriptions(characterDescriptions)
        dialogue_lines = self._extract_dialogue_lines(scriptText)
        self._save_lines_as_text_files(dialogue_lines, gender_map, outputDirectory)

        return (f"Dialogue lines processed and saved in {outputDirectory}.",)

    def _parse_character_descriptions(self, descriptions):
        gender_map = {}
        for line in descriptions.split('\n'):
            if '=' in line:
                name, desc = line.split('=')
                gender = 'woman' if 'woman' in desc.lower() else 'man'
                gender_map[name.strip()] = gender
        return gender_map

    def _extract_dialogue_lines(self, script):
        # This pattern ensures that scene descriptions are excluded and only dialogue lines are captured.
        lines = re.findall(r'#(\w+):\s*(.*?)$', script, re.DOTALL | re.MULTILINE)
        return [(actor.strip(), text.strip()) for actor, text in lines]

    def _save_lines_as_text_files(self, dialogue_lines, gender_map, outputDirectory):
        sequential_order = 1
        for actor, line in dialogue_lines:
            gender = gender_map.get(actor, "unknown")
            filename = f"{actor}{sequential_order}_{gender}.txt"
            filepath = os.path.join(outputDirectory, filename)
            with open(filepath, 'w') as file:
                file.write(line)
            sequential_order += 1

# Node registration for ComfyUI, with updated class and function names to reflect versioning.
NODE_CLASS_MAPPINGS = {
    "DialogueLinesToFileNodeV3": DialogueLinesToFileNodeV3,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "DialogueLinesToFileNodeV3": "Dialogue Lines to File V3",
}
