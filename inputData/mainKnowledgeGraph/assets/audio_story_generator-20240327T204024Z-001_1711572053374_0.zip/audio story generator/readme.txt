AudioStoryGenerator

I made this with ChatGPT so I do not take any credit for it. Neither do I fully understand what it does. 

The folders these nodes create appear on the main ComfyUI folder from where it is launched. I used 
the embedded ComfyUI with the manager. 

Basically the dynamic script generator needs really strict rules. You have to write the place of the scene 
TOGETHER else you get error. Also Every place has to be seperated by , sign and there has to be empty space 
after teh , sign. The (x,x,x) generates a procedural script with format (narrator lines, actor 1 lines, actor 
2 lines etc) It is important there is a space between place and ( so like place (x,x,x), else you get error. 

Each scene has a format: 

((Scene: Vulcan in the future)) 

Where Vulcan is the place followed by era which is defined in the dynamic script generator. 

The procedural script format is: 

((Scene: Vulcan in the future))
#narrator: [Introductory narration]
#Bob: [Actor's line]
#Bob: [Actor's line]
#uhura: [Actor's line]
#uhura: [Actor's line]
((Scene: PlanetVulcan in the future))
#Bob: [Actor's line]
#Bob: [Actor's line]
#Bob: [Actor's line]
#uhura: [Actor's line] 

etc. 

It generates a genre which could be used in the prompt. But I did not use it as the AI would go off 
the rails with it. Ask from ChatGPT after feeding it the instructions at: 

https://www.reddit.com/r/comfyui/comments/18wp6oj/tutorial_create_a_custom_node_in_5_minutes/ (copy and paste 
the post and chatgpt 4 will understand how scripts work. 

Then feed it the dynamicscriptgenerator.py file and ask how to use the drama in a prompt. It will figure it out 
for you. 

This node also generates characterdescription.txt out of the character description you wrote. So name=(character GENDER), etc. 
The gender is important as that is used later to generate voice. Also, you could use it to generate image 
or video. 

I did this using LM Studio local AI server. So to do that install LM Studio and go to the "playground" where 
you should load the model you want to use and then copy the model name to the model in the dynamic script 
generator prompt. 

The model makes all the difference. Some models will understand the task, most wont. I am using Mixtral q5 or 
q4. They. Ahem. Struggle. Perhaps openai API would be best but I am broke so. 

In the next phase. The dialogue lines are broken to text files and given a sequential order + gender in form 
of nameX_gender.txt and they are put to dialogue_Lines_To_File_V3 folder (default). 

The next node uses Microsoft speech TTS server to speak out the lines according to gender and puts them to 
audio_output folder with the same convention as the text files. The folder is important as the audio 
combiner node that comes next expects them to be there. 

So the last important node is the audiocombiner node that reads the audio files in sequential order 
and combines them to a file. 

One could build on this in all sorts of ways. 

If you have problems, send the code to chatgpt and ask why it does not work. It can figure it out. 

The TTS is done with ComfyUI_MSSpeech_TTS so install those nodes. 

Remember to empty the dialogue line text and audio files before generating the next story as else it may use the
old ones. 

Note! To render a new combined audio, you have to change something in the dynamic script generator as else 
it considers it has done the render already. Just a letter or something. 
